'use client';

import { useEffect } from 'react';
import { Toaster } from '@/components/ui/sonner';
import { LanguageProvider } from '@/lib/i18n';
import { DataProvider } from '@/lib/data-service';
import { useSiteSettings } from '@/lib/site-settings';

/**
 * Updates the browser favicon dynamically based on the logo.icon_url site setting.
 * This runs client-side after mount to apply the custom favicon from the admin panel.
 * Falls back to local /logo-icon-192.png if no custom icon is configured.
 */
function DynamicFavicon() {
  const { getText, loading } = useSiteSettings();

  useEffect(() => {
    if (loading) return;

    const iconUrl = getText('logo.icon_url') || '/logo-odg.jpg';

    // Find existing favicon link or create a new one
    let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    link.type = 'image/png';
    link.href = iconUrl;

    // Also set as apple-touch-icon
    let appleLink = document.querySelector("link[rel~='apple-touch-icon']") as HTMLLinkElement;
    if (!appleLink) {
      appleLink = document.createElement('link');
      appleLink.rel = 'apple-touch-icon';
      document.head.appendChild(appleLink);
    }
    appleLink.href = getText('logo.icon_url') || '/logo-odg.jpg';
  }, [getText, loading]);

  return null; // This component renders nothing
}

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <LanguageProvider>
      <DataProvider>
        <DynamicFavicon />
        {children}
      </DataProvider>
      <Toaster position="top-right" richColors closeButton />
    </LanguageProvider>
  );
}
