'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Settings, Save, Loader2, RefreshCw, MapPin, Phone, Mail, Clock, MessageCircle, Image, Upload, ExternalLink } from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { supabase, isSupabaseConfigured, getStorageUrl, STORAGE_BUCKETS } from '@/lib/supabase';
import { useSiteSettings } from '@/lib/site-settings';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

interface SettingRow {
  id: string;
  key: string;
  value_fr: string | null;
  value_ar: string | null;
  value_json: Record<string, unknown> | unknown[] | null;
  category: string;
  label: string | null;
  type: string;
}

type SettingField = {
  key: string;
  label_fr: string;
  label_ar: string;
  type: 'text' | 'textarea' | 'json' | 'number' | 'image';
  category: string;
};

const logoFields: SettingField[] = [
  { key: 'logo.icon_url', label_fr: 'Logo Icône (favicon / petite icône)', label_ar: 'أيقونة الشعار', type: 'image', category: 'logo' },
  { key: 'logo.full_url', label_fr: 'Logo Complet (image avec texte)', label_ar: 'الشعار الكامل', type: 'image', category: 'logo' },
  { key: 'logo.brand_text', label_fr: 'Texte de la marque (ex: ODG)', label_ar: 'نص العلامة التجارية', type: 'text', category: 'logo' },
];

const aboutFields: SettingField[] = [
  { key: 'about.history.p1', label_fr: 'Histoire — Paragraphe 1', label_ar: 'القصة — فقرة 1', type: 'textarea', category: 'about' },
  { key: 'about.history.p2', label_fr: 'Histoire — Paragraphe 2', label_ar: 'القصة — فقرة 2', type: 'textarea', category: 'about' },
];

const contactFields: SettingField[] = [
  { key: 'contact.address_fr', label_fr: 'Adresse (Français)', label_ar: 'العنوان (فرنسي)', type: 'text', category: 'contact' },
  { key: 'contact.address_ar', label_fr: 'Adresse (Arabe)', label_ar: 'العنوان (عربي)', type: 'text', category: 'contact' },
  { key: 'contact.phone', label_fr: 'Téléphone', label_ar: 'الهاتف', type: 'text', category: 'contact' },
  { key: 'contact.email', label_fr: 'Email', label_ar: 'البريد الإلكتروني', type: 'text', category: 'contact' },
  { key: 'contact.whatsapp', label_fr: 'WhatsApp (ex: +213771888948)', label_ar: 'واتساب', type: 'text', category: 'contact' },
  { key: 'contact.hours_fr', label_fr: 'Horaires (Français)', label_ar: 'ساعات العمل (فرنسي)', type: 'text', category: 'contact' },
  { key: 'contact.hours_ar', label_fr: 'Horaires (Arabe)', label_ar: 'ساعات العمل (عربي)', type: 'text', category: 'contact' },
];

const socialFields: SettingField[] = [
  { key: 'social.facebook', label_fr: 'Facebook URL', label_ar: 'فيسبوك', type: 'text', category: 'social' },
  { key: 'social.instagram', label_fr: 'Instagram URL', label_ar: 'إنستغرام', type: 'text', category: 'social' },
  { key: 'social.linkedin', label_fr: 'LinkedIn URL', label_ar: 'لينكدإن', type: 'text', category: 'social' },
  { key: 'social.youtube', label_fr: 'YouTube URL', label_ar: 'يوتيوب', type: 'text', category: 'social' },
];

const statsFields: SettingField[] = [
  { key: 'stats.clinics', label_fr: 'Nombre de cabinets équipés', label_ar: 'عدد العيادات المجهزة', type: 'number', category: 'stats' },
  { key: 'stats.wilayas', label_fr: 'Nombre de wilayas couvertes', label_ar: 'عدم الولايات المغطاة', type: 'number', category: 'stats' },
  { key: 'stats.brands', label_fr: 'Nombre de marques', label_ar: 'عدد العلامات التجارية', type: 'number', category: 'stats' },
  { key: 'stats.sav_hours', label_fr: 'Heures SAV', label_ar: 'ساعات ما بعد البيع', type: 'text', category: 'stats' },
];

const mapFields: SettingField[] = [
  { key: 'contact.map.google_maps_url', label_fr: 'Lien Google Maps (URL complète)', label_ar: 'رابط خرائط جوجل', type: 'text', category: 'map' },
  { key: 'contact.map.lat', label_fr: 'Latitude (pour fallback OpenStreetMap)', label_ar: 'خط العرض', type: 'text', category: 'map' },
  { key: 'contact.map.lng', label_fr: 'Longitude (pour fallback OpenStreetMap)', label_ar: 'خط الطول', type: 'text', category: 'map' },
  { key: 'contact.map.zoom', label_fr: 'Zoom', label_ar: 'تكبير', type: 'text', category: 'map' },
  { key: 'contact.map.address_fr', label_fr: 'Label carte (FR)', label_ar: 'تسمية الخريطة (فرنسي)', type: 'text', category: 'map' },
  { key: 'contact.map.address_ar', label_fr: 'Label carte (AR)', label_ar: 'تسمية الخريطة (عربي)', type: 'text', category: 'map' },
];

const productInfoFields: SettingField[] = [
  { key: 'product.default_warranty', label_fr: 'Garantie par défaut (ex: 2 ans)', label_ar: 'الضمان الافتراضي', type: 'text', category: 'product_info' },
  { key: 'product.default_delivery_fr', label_fr: 'Délai de livraison par défaut (FR)', label_ar: 'وقت التوصيل الافتراضي (فرنسي)', type: 'text', category: 'product_info' },
  { key: 'product.default_delivery_ar', label_fr: 'Délai de livraison par défaut (AR)', label_ar: 'وقت التوصيل الافتراضي (عربي)', type: 'text', category: 'product_info' },
  { key: 'product.sav_info_fr', label_fr: 'Info Service Après-Vente (FR)', label_ar: 'معلومات ما بعد البيع (فرنسي)', type: 'textarea', category: 'product_info' },
  { key: 'product.sav_info_ar', label_fr: 'Info Service Après-Vente (AR)', label_ar: 'معلومات ما بعد البيع (عربي)', type: 'textarea', category: 'product_info' },
  { key: 'product.installation_info_fr', label_fr: 'Info Installation (FR)', label_ar: 'معلومات التركيب (فرنسي)', type: 'textarea', category: 'product_info' },
  { key: 'product.installation_info_ar', label_fr: 'Info Installation (AR)', label_ar: 'معلومات التركيب (عربي)', type: 'textarea', category: 'product_info' },
  { key: 'product.formation_info_fr', label_fr: 'Info Formation (FR)', label_ar: 'معلومات التدريب (فرنسي)', type: 'textarea', category: 'product_info' },
  { key: 'product.formation_info_ar', label_fr: 'Info Formation (AR)', label_ar: 'معلومات التدريب (عربي)', type: 'textarea', category: 'product_info' },
];

const allFieldGroups = [
  { title: 'Logo & Marque', icon: Image, fields: logoFields },
  { title: 'À propos', icon: Settings, fields: aboutFields },
  { title: 'Contact', icon: Phone, fields: contactFields },
  { title: 'Réseaux sociaux', icon: MessageCircle, fields: socialFields },
  { title: 'Statistiques', icon: Settings, fields: statsFields },
  { title: 'Carte & Localisation', icon: MapPin, fields: mapFields },
  { title: 'Infos Produits (Garantie, SAV, Installation, Formation)', icon: Settings, fields: productInfoFields },
];

export default function AdminSettings() {
  const { t, isRTL } = useTranslation();
  const { getText, refresh } = useSiteSettings();
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [uploading, setUploading] = useState<string | null>(null); // key of field being uploaded

  const allFieldsFlat = [...logoFields, ...aboutFields, ...contactFields, ...socialFields, ...statsFields, ...mapFields, ...productInfoFields];

  // Load all settings into form
  useEffect(() => {
    const loadSettings = () => {
      const values: Record<string, string> = {};

      for (const field of allFieldsFlat) {
        if (field.type === 'json') continue;
        const val = getText(field.key);
        values[field.key] = val || '';
      }

      setFormValues(values);
      setLoading(false);
    };

    // Small delay to let useSiteSettings fetch first
    const timer = setTimeout(loadSettings, 300);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [getText]);

  const updateField = (key: string, value: string) => {
    setFormValues((prev) => ({ ...prev, [key]: value }));
  };

  // Upload image to Supabase storage for logo fields
  const handleLogoUpload = useCallback(async (fieldKey: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!isSupabaseConfigured()) {
      toast.error('Supabase non configuré');
      return;
    }

    setUploading(fieldKey);
    try {
      const ext = file.name.split('.').pop() || 'png';
      const fileName = `logo-${fieldKey.replace(/\./g, '-')}-${Date.now()}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from(STORAGE_BUCKETS.PRODUCT_IMAGES)
        .upload(fileName, file, { cacheControl: '3600', upsert: false });

      if (uploadError) {
        toast.error(`Erreur upload: ${uploadError.message}`);
        return;
      }

      const publicUrl = getStorageUrl(STORAGE_BUCKETS.PRODUCT_IMAGES, fileName);
      updateField(fieldKey, publicUrl);
      toast.success('Image uploadée avec succès');
    } catch (err) {
      console.error('Upload failed:', err);
      toast.error("Erreur lors de l'upload de l'image");
    } finally {
      setUploading(null);
      e.target.value = '';
    }
  }, []);

  const saveAll = async () => {
    setSaving(true);
    try {
      if (!isSupabaseConfigured()) {
        toast.error('Supabase non configuré');
        return;
      }

      for (const field of allFieldsFlat) {
        if (field.type === 'json') continue;

        const value = formValues[field.key] ?? '';

        // Determine if this is a _fr or _ar field
        if (field.key.endsWith('_fr')) {
          await upsertSetting(field.key, value, null, null, field.category, field.label_fr, field.type === 'image' ? 'text' : field.type);
        } else if (field.key.endsWith('_ar')) {
          await upsertSetting(field.key, null, value, null, field.category, field.label_ar, field.type === 'image' ? 'text' : field.type);
        } else {
          await upsertSetting(field.key, value, null, null, field.category, field.label_fr, field.type === 'image' ? 'text' : field.type);
        }
      }

      // Invalidate cache
      refresh();
      toast.success(t('common.success'));
    } catch (err) {
      console.error('Error saving settings:', err);
      toast.error("Erreur lors de l'enregistrement");
    } finally {
      setSaving(false);
    }
  };

  const upsertSetting = async (
    key: string,
    value_fr: string | null,
    value_ar: string | null,
    value_json: Record<string, unknown> | unknown[] | null,
    category: string,
    label: string,
    type: string,
  ) => {
    // Check if setting exists
    const { data: existing } = await supabase
      .from('site_settings')
      .select('id')
      .eq('key', key)
      .maybeSingle();

    if (existing) {
      const updateData: Record<string, unknown> = { updated_at: new Date().toISOString() };
      if (value_fr !== null) updateData.value_fr = value_fr;
      if (value_ar !== null) updateData.value_ar = value_ar;
      if (value_json !== null) updateData.value_json = value_json;

      const { error } = await supabase
        .from('site_settings')
        .update(updateData)
        .eq('id', existing.id);
      if (error) throw error;
    } else {
      const { error } = await supabase
        .from('site_settings')
        .insert([{
          key,
          value_fr: value_fr || null,
          value_ar: value_ar || null,
          value_json: value_json,
          category,
          label,
          type,
        }]);
      if (error) throw error;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20" dir={isRTL ? 'rtl' : 'ltr'}>
        <Loader2 className="h-8 w-8 animate-spin text-neutral-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Paramètres du site
        </h2>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={async () => { refresh(); toast.success('Cache actualisé'); }}
            className="gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            Actualiser
          </Button>
          <Button
            onClick={saveAll}
            disabled={saving}
            className="gap-2"
            style={{ backgroundColor: 'var(--dental-primary)' }}
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            {saving ? 'Enregistrement...' : 'Enregistrer tout'}
          </Button>
        </div>
      </div>

      {/* Settings Groups */}
      {allFieldGroups.map((group, gi) => (
        <motion.div
          key={group.title}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: gi * 0.05 }}
        >
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <group.icon className="h-5 w-5" style={{ color: 'var(--dental-primary)' }} />
                {group.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {group.fields.map((field) => (
                <div key={field.key} className="space-y-1.5">
                  <Label className="text-sm font-medium">
                    {field.label_fr}
                    {field.key.endsWith('_ar') && (
                      <span className="text-neutral-400 ms-1" dir="rtl">({field.label_ar})</span>
                    )}
                  </Label>

                  {/* Image upload field */}
                  {field.type === 'image' ? (
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <Input
                          value={formValues[field.key] || ''}
                          onChange={(e) => updateField(field.key, e.target.value)}
                          placeholder="URL de l'image ou uploader ci-dessous"
                          dir="ltr"
                        />
                        <label htmlFor={`upload-${field.key}`}>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="gap-1.5 cursor-pointer shrink-0"
                            disabled={uploading === field.key}
                            onClick={() => {}}
                          >
                            {uploading === field.key ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Upload className="h-4 w-4" />
                            )}
                            Upload
                          </Button>
                        </label>
                        <input
                          id={`upload-${field.key}`}
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handleLogoUpload(field.key, e)}
                        />
                      </div>
                      {formValues[field.key] && (
                        <div className="flex items-center gap-3">
                          <div className="w-16 h-16 rounded-lg border border-neutral-200 overflow-hidden bg-neutral-50 flex items-center justify-center">
                            <img
                              src={formValues[field.key]}
                              alt="Aperçu"
                              className="w-full h-full object-contain p-1"
                              onError={(e) => {
                                const img = e.target as HTMLImageElement;
                                img.style.display = 'none';
                              }}
                            />
                          </div>
                          <span className="text-xs text-neutral-500 truncate max-w-[200px]">
                            {formValues[field.key]}
                          </span>
                        </div>
                      )}
                    </div>
                  ) : field.type === 'textarea' ? (
                    <Textarea
                      rows={4}
                      value={formValues[field.key] || ''}
                      onChange={(e) => updateField(field.key, e.target.value)}
                      placeholder={field.label_fr}
                      dir={field.key.endsWith('_ar') ? 'rtl' : 'ltr'}
                    />
                  ) : (
                    <Input
                      value={formValues[field.key] || ''}
                      onChange={(e) => updateField(field.key, e.target.value)}
                      placeholder={field.label_fr}
                      dir={field.key.endsWith('_ar') ? 'rtl' : 'ltr'}
                      type={field.type === 'number' ? 'number' : 'text'}
                    />
                  )}

                  {/* Helper text for Google Maps */}
                  {field.key === 'contact.map.google_maps_url' && (
                    <p className="text-xs text-neutral-400 flex items-center gap-1">
                      <ExternalLink className="h-3 w-3" />
                      Ouvrez Google Maps, recherchez votre adresse, cliquez sur &quot;Partager&quot; &gt; &quot;Copier le lien&quot; et collez-le ici.
                    </p>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      ))}

      {/* Save button at bottom */}
      <div className="flex justify-end pt-4">
        <Button
          onClick={saveAll}
          disabled={saving}
          className="gap-2 min-w-[200px]"
          style={{ backgroundColor: 'var(--dental-primary)' }}
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {saving ? 'Enregistrement...' : 'Enregistrer tous les paramètres'}
        </Button>
      </div>
    </div>
  );
}
