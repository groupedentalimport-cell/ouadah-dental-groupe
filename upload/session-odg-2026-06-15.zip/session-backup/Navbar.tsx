'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Stethoscope, Globe, Menu, X } from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { useSiteSettings } from '@/lib/site-settings';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetClose,
} from '@/components/ui/sheet';

interface NavItem {
  label: string;
  route: string;
}

export default function Navbar() {
  const { language, setLanguage, t, isRTL } = useTranslation();
  const { navigate, route: currentRoute } = useRouter();
  const { getText } = useSiteSettings();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Dynamic logo settings — fallback to local logo files if not configured in admin
  const logoIconUrl = getText('logo.icon_url') || '/logo-odg.jpg';
  const logoFullUrl = getText('logo.full_url') || '/logo-odg-full.png';
  const brandText = getText('logo.brand_text') || t('nav.brand');

  // Detect scroll for shadow
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: NavItem[] = [
    { label: t('nav.catalogue'), route: '/catalogue' },
    { label: t('nav.blog'), route: '/blog' },
    { label: t('nav.about'), route: '/about' },
    { label: t('nav.contact'), route: '/contact' },
  ];

  const toggleLanguage = () => {
    setLanguage(language === 'fr' ? 'ar' : 'fr');
  };

  const handleNavigate = (path: string) => {
    navigate(path);
    setMobileOpen(false);
  };

  const isActive = (itemRoute: string) => {
    const routeName = itemRoute.replace(/^\//, '') || 'home';
    return currentRoute === routeName;
  };

  // Render the logo icon - use custom icon URL or fallback to Stethoscope
  const renderLogoIcon = (className: string = "h-7 w-7 md:h-8 md:w-8 text-primary") => {
    if (logoIconUrl) {
      return (
        <img
          src={logoIconUrl}
          alt="Logo"
          className={className.replace('text-primary', '')}
          style={{ objectFit: 'contain' }}
          onError={(e) => {
            // Fallback to Stethoscope on image error
            const img = e.target as HTMLImageElement;
            img.style.display = 'none';
            if (img.nextElementSibling) {
              (img.nextElementSibling as HTMLElement).style.display = '';
            }
          }}
        />
      );
    }
    return <Stethoscope className={className} />;
  };

  // Render the full logo or fallback to icon + text
  const renderLogo = () => {
    if (logoFullUrl) {
      return (
        <img
          src={logoFullUrl}
          alt={brandText}
          className="h-8 md:h-10"
          style={{ objectFit: 'contain' }}
          onError={(e) => {
            // Fallback to icon + text on image error
            const img = e.target as HTMLImageElement;
            img.style.display = 'none';
            if (img.parentElement) {
              const fallback = img.parentElement.querySelector('.logo-fallback') as HTMLElement;
              if (fallback) fallback.style.display = 'flex';
            }
          }}
        />
      );
    }
    return null;
  };

  return (
    <>
      <motion.header
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className={`sticky top-0 z-50 w-full transition-shadow duration-300 ${
          scrolled
            ? 'bg-white/95 backdrop-blur-md shadow-md'
            : 'bg-white backdrop-blur-md'
        }`}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <nav className="mx-auto flex h-14 md:h-16 max-w-7xl items-center justify-between px-4 md:px-6">
          {/* Logo */}
          <div
            className={`flex items-center gap-2 cursor-pointer ${
              isRTL ? 'flex-row-reverse' : ''
            }`}
            onClick={() => handleNavigate('/')}
          >
            {logoFullUrl ? (
              <>
                {renderLogo()}
                <div className="logo-fallback flex items-center gap-2" style={{ display: 'none' }}>
                  {renderLogoIcon()}
                  <span
                    className="text-xl font-display font-bold text-primary"
                    style={{ fontFamily: "var(--font-syne), 'Syne', sans-serif" }}
                  >
                    {brandText}
                  </span>
                </div>
              </>
            ) : (
              <>
                {renderLogoIcon()}
                <span
                  className="text-xl font-display font-bold text-primary"
                  style={{ fontFamily: "var(--font-syne), 'Syne', sans-serif" }}
                >
                  {brandText}
                </span>
              </>
            )}
          </div>

          {/* Center Nav Links — Desktop only */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.route}
                onClick={() => handleNavigate(item.route)}
                className={`px-3 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                  isActive(item.route)
                    ? 'text-primary bg-primary/5'
                    : 'text-neutral-800 hover:text-primary hover:bg-primary/5'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Right side — Language + CTA */}
          <div
            className={`hidden md:flex items-center gap-3 ${
              isRTL ? 'flex-row-reverse' : ''
            }`}
          >
            {/* Language Switcher */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleLanguage}
              className="gap-1.5 text-sm text-neutral-700 hover:text-primary"
              aria-label={t('nav.language')}
            >
              <Globe className="h-4 w-4" />
              <span className="font-medium">
                {language === 'fr' ? 'FR' : 'AR'}
              </span>
            </Button>

            {/* CTA Button */}
            <Button
              onClick={() => handleNavigate('/devis')}
              className="bg-primary-500 text-white px-5 py-2 rounded-lg hover:bg-primary-600 transition-colors duration-200 text-sm font-semibold shadow-sm"
              style={{
                backgroundColor: 'var(--dental-primary)',
              }}
            >
              {t('nav.quote')}
            </Button>
          </div>

          {/* Mobile Hamburger */}
          <div className="flex md:hidden items-center gap-2">
            {/* Language Switcher — Mobile */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleLanguage}
              className="h-9 w-9 text-neutral-700"
              aria-label={t('nav.language')}
            >
              <Globe className="h-4 w-4" />
            </Button>

            {/* Hamburger Menu */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileOpen(true)}
              className="h-9 w-9 text-neutral-700"
              aria-label={t('nav.menu')}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </nav>
      </motion.header>

      {/* Mobile Drawer */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent
          side={isRTL ? 'right' : 'left'}
          className="w-[300px] sm:w-[350px] p-0"
        >
          <SheetHeader className="p-4 border-b border-neutral-100">
            <SheetTitle className="flex items-center gap-2">
              {logoFullUrl ? (
                <img
                  src={logoFullUrl}
                  alt={brandText}
                  className="h-8"
                  style={{ objectFit: 'contain' }}
                  onError={(e) => {
                    const img = e.target as HTMLImageElement;
                    img.style.display = 'none';
                  }}
                />
              ) : (
                <>
                  {logoIconUrl ? (
                    <img src={logoIconUrl} alt="Logo" className="h-6 w-6" style={{ objectFit: 'contain' }} />
                  ) : (
                    <Stethoscope className="h-6 w-6 text-primary" />
                  )}
                  <span
                    className="text-lg font-display font-bold text-primary"
                    style={{ fontFamily: "var(--font-syne), 'Syne', sans-serif" }}
                  >
                    {brandText}
                  </span>
                </>
              )}
            </SheetTitle>
            <SheetDescription className="sr-only">Navigation menu</SheetDescription>
          </SheetHeader>

          {/* Mobile Navigation Links */}
          <div className="flex flex-col py-4">
            {navItems.map((item) => (
              <button
                key={item.route}
                onClick={() => handleNavigate(item.route)}
                className={`px-6 py-3.5 text-left text-base font-medium transition-colors duration-200 ${
                  isRTL ? 'text-right' : 'text-left'
                } ${
                  isActive(item.route)
                    ? 'text-primary bg-primary/5 border-s-2 border-primary'
                    : 'text-neutral-800 hover:text-primary hover:bg-primary/5'
                }`}
                style={isRTL ? { borderRightWidth: isActive(item.route) ? '2px' : undefined, borderRightColor: 'var(--dental-primary)' } : { borderLeftWidth: isActive(item.route) ? '2px' : undefined, borderLeftColor: 'var(--dental-primary)' }}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Mobile CTA */}
          <div className="px-6 py-4 border-t border-neutral-100">
            <Button
              onClick={() => handleNavigate('/devis')}
              className="w-full text-white px-5 py-3 rounded-lg transition-colors duration-200 text-sm font-semibold shadow-sm"
              style={{
                backgroundColor: 'var(--dental-primary)',
              }}
            >
              {t('nav.quote')}
            </Button>
          </div>

          {/* Mobile Language Switch */}
          <div className="px-6 py-4 border-t border-neutral-100">
            <Button
              variant="outline"
              onClick={toggleLanguage}
              className="w-full gap-2"
            >
              <Globe className="h-4 w-4" />
              <span>
                {language === 'fr' ? 'Français' : 'العربية'}
              </span>
              <span className="text-neutral-400">/</span>
              <span className="text-neutral-400">
                {language === 'fr' ? 'العربية' : 'Français'}
              </span>
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
