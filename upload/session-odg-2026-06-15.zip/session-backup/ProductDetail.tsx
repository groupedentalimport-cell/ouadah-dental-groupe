'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  ShoppingCart,
  FileDown,
  ZoomIn,
  X,
  Check,
  Package,
  GraduationCap,
  Shield,
  Truck,
  GitCompareArrows,
  Wrench,
  Headphones,
} from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { getPdfUrl } from '@/lib/supabase';
import { useRouter, useRouteParams } from '@/lib/router';
import { useData } from '@/lib/data-service';
import { useQuoteCart } from '@/hooks/useQuoteCart';
import { useCompare } from '@/hooks/useCompare';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { toast } from 'sonner';
import ProductVideos from '@/components/dental/product/ProductVideos';

/**
 * Sanitize HTML content to prevent raw HTML tags from appearing as visible text.
 * Handles multiple common issues:
 * - Double-encoded HTML entities (e.g., &amp;lt; should render as < not &lt;)
 * - Stray closing tags without matching opening tags (e.g., </p></li></ul><h3> appearing as text)
 * - Plain text that should be wrapped in <p> tags
 * - Malformed HTML from rich text editors or database migrations
 */
function sanitizeHtml(html: string): string {
  if (!html) return '';

  let sanitized = html.trim();
  if (!sanitized) return '';

  // Step 1: Decode double-encoded HTML entities
  // E.g., &amp;lt; → &lt; → <  or  &amp;quot; → &quot; → "
  // We only do ONE round of decoding to avoid XSS
  sanitized = sanitized
    .replace(/&amp;lt;/g, '<')
    .replace(/&amp;gt;/g, '>')
    .replace(/&amp;quot;/g, '"')
    .replace(/&amp;#39;/g, "'")
    .replace(/&amp;amp;/g, '&');

  // Step 2: Remove any visible raw HTML closing/opening tags that appear as literal text
  // This happens when content has stray tags like: Some text</p></li></ul><h3>More text
  // These stray tags were likely part of a larger HTML structure that got corrupted
  // We remove closing tags that don't have corresponding opening tags in the content

  // First, find all opening tags and their tag names
  const openingTags = sanitized.match(/<(p|li|ul|ol|h[1-6]|div|span|strong|em|blockquote|table|tr|td|th|thead|tbody)[^>]*>/gi) || [];
  const openingTagNames = openingTags.map(t => {
    const match = t.match(/<\w+/);
    return match ? match[0].toLowerCase().replace('<', '') : '';
  });

  // Find all closing tags
  const closingTagPattern = /<\/(p|li|ul|ol|h[1-6]|div|span|strong|em|blockquote|table|tr|td|th|thead|tbody)>/gi;
  const closingTags = sanitized.match(closingTagPattern) || [];
  const closingTagNames = closingTags.map(t => {
    const match = t.match(/<\/\w+/);
    return match ? match[0].toLowerCase().replace('</', '') : '';
  });

  // Count opening vs closing tags for each tag type
  const openCounts: Record<string, number> = {};
  const closeCounts: Record<string, number> = {};
  openingTagNames.forEach(name => { openCounts[name] = (openCounts[name] || 0) + 1; });
  closingTagNames.forEach(name => { closeCounts[name] = (closeCounts[name] || 0) + 1; });

  // If there are more closing tags than opening tags for any type, remove the excess
  // This removes stray closing tags like </p></li></ul> that appear as visible text
  for (const tagName of Object.keys(closeCounts)) {
    const excess = (closeCounts[tagName] || 0) - (openCounts[tagName] || 0);
    if (excess > 0) {
      // Remove excess closing tags of this type, starting from the end
      let removed = 0;
      sanitized = sanitized.replace(new RegExp(`<\/${tagName}>`, 'gi'), (match) => {
        if (removed < excess) {
          removed++;
          return ''; // Remove the stray closing tag
        }
        return match;
      });
    }
  }

  // Step 3: Clean up any empty or whitespace-only content left after removing stray tags
  // Remove sequences of whitespace between tags
  sanitized = sanitized.replace(/>\s+</g, '><');

  // Step 4: If content looks like plain text (no HTML tags at all), wrap in <p>
  if (!sanitized.includes('<')) {
    return `<p>${sanitized}</p>`;
  }

  // Step 5: Wrap content starting with plain text in <p> tags
  if (sanitized.length > 0 && !sanitized.startsWith('<')) {
    sanitized = `<p>${sanitized}</p>`;
  }

  // Step 6: Ensure the HTML ends with a closing tag (not stray text after last tag)
  // If content ends with text after the last closing tag, wrap that text
  const lastClosingTag = sanitized.lastIndexOf('</');
  if (lastClosingTag >= 0 && lastClosingTag < sanitized.length - 1) {
    const afterLastTag = sanitized.substring(lastClosingTag);
    const closeTagEnd = afterLastTag.indexOf('>');
    if (closeTagEnd >= 0 && closeTagEnd < afterLastTag.length - 1) {
      // There's text after the last closing tag - this shouldn't normally happen
      const textAfter = afterLastTag.substring(closeTagEnd + 1).trim();
      if (textAfter) {
        // This is likely stray text, wrap it
        sanitized = sanitized.substring(0, lastClosingTag + closeTagEnd + 1) + `<p>${textAfter}</p>`;
      }
    }
  }

  return sanitized;
}

export default function ProductDetail() {
  const { language, t, isRTL } = useTranslation();
  const { navigate } = useRouter();
  const params = useRouteParams();
  const { getProductBySlug, getRelatedProducts, getCategoryBySlug, formatPrice } = useData();
  const { addItem, isInCart } = useQuoteCart();
  const { toggleItem: toggleCompareItem, isInCompare, maxReached: maxCompareReached } = useCompare();

  const slug = params.slug || '';
  const product = getProductBySlug(slug);

  const [selectedImage, setSelectedImage] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  if (!product) {
    return (
      <div
        className="w-full py-20 flex flex-col items-center justify-center text-center"
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <div
          className="w-24 h-24 rounded-full flex items-center justify-center mb-6"
          style={{ backgroundColor: 'var(--dental-primary-light)' }}
        >
          <Package className="h-10 w-10" style={{ color: 'var(--dental-primary)' }} />
        </div>
        <h2
          className="text-xl font-bold text-foreground mb-2"
          style={{
            fontFamily: isRTL
              ? "var(--font-cairo), 'Cairo', sans-serif"
              : "var(--font-syne), 'Syne', sans-serif",
          }}
        >
          {t('products.noResults')}
        </h2>
        <Button
          variant="outline"
          onClick={() => navigate('/catalogue')}
          className="mt-4 gap-2"
        >
          <ArrowLeft className={cn('h-4 w-4', isRTL && 'rotate-180')} />
          {t('productDetail.backToCatalogue')}
        </Button>
      </div>
    );
  }

  const category = getCategoryBySlug(product.category);
  const relatedProducts = getRelatedProducts(product.id, 3);
  const images = product.images.length > 0 ? product.images : ['https://placehold.co/600x400/E2E8F0/64748B?text=No+Image'];

  const handleAddToQuote = () => {
    addItem({
      id: product.id,
      slug: product.slug,
      name: product.name,
      price: product.price,
      image: product.images[0],
      category: product.category,
      ref: product.ref,
    });
    toast.success(t('products.addToQuote'), {
      description: product.name[language],
    });
  };

  const handleToggleCompare = () => {
    const wasInCompare = isInCompare(product.id);
    toggleCompareItem({
      id: product.id,
      slug: product.slug,
      name: product.name,
      price: product.price,
      image: product.images[0],
      category: product.category,
      brand: product.brand,
      ref: product.ref,
    });
    if (!wasInCompare) {
      toast.success(t('products.addedToCompare'), {
        description: product.name[language],
      });
    } else {
      toast.info(t('products.removedFromCompare'), {
        description: product.name[language],
      });
    }
  };

  return (
    <div
      className="w-full py-8 md:py-12"
      style={{ backgroundColor: '#F8FAFC' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        {/* Back Button */}
        <motion.div
          initial={{ opacity: 0, x: isRTL ? 20 : -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          className="mb-6"
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/catalogue')}
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className={cn('h-4 w-4', isRTL && 'rotate-180')} />
            {t('productDetail.backToCatalogue')}
          </Button>
        </motion.div>

        {/* Main Content: 2 Columns Desktop, Stacked Mobile */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left: Image Gallery */}
          <motion.div
            initial={{ opacity: 0, x: isRTL ? 30 : -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            {/* Main Image */}
            <div
              className="relative w-full rounded-xl overflow-hidden bg-white border border-neutral-100 cursor-zoom-in group"
              style={{ aspectRatio: '4/3' }}
              onClick={() => setLightboxOpen(true)}
            >
              <AnimatePresence mode="wait">
                <motion.img
                  key={selectedImage}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  src={images[selectedImage]}
                  alt={product.name[language]}
                  className="w-full h-full object-cover"
                  onError={(e) => { const t = e.target as HTMLImageElement; t.src = `https://placehold.co/600x400/E2E8F0/64748B?text=${encodeURIComponent(product.name[language]?.slice(0,30)||'Image')}`; }}
                />
              </AnimatePresence>
              <div className="absolute inset-0 flex items-center justify-center bg-black/0 group-hover:bg-black/10 transition-colors duration-200">
                <ZoomIn className="h-8 w-8 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
              </div>
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-3 mt-4">
                {images.slice(0, 4).map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={cn(
                      'w-20 h-16 md:w-24 md:h-18 rounded-lg overflow-hidden border-2 transition-all duration-200',
                      selectedImage === idx
                        ? 'border-primary-500 shadow-md'
                        : 'border-transparent hover:border-neutral-300'
                    )}
                  >
                    <img
                      src={img}
                      alt={`${product.name[language]} - ${idx + 1}`}
                      className="w-full h-full object-cover"
                      onError={(e) => { const t = e.target as HTMLImageElement; t.src = `https://placehold.co/600x400/E2E8F0/64748B?text=${encodeURIComponent(product.name[language]?.slice(0,20)||'Image')}`; }}
                    />
                  </button>
                ))}
              </div>
            )}
          </motion.div>

          {/* Right: Product Info */}
          <motion.div
            initial={{ opacity: 0, x: isRTL ? -30 : 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col gap-5"
          >
            {/* Category Badge */}
            {category && (
              <Badge
                className="w-fit text-xs font-medium px-3 py-1 rounded-full"
                style={{ backgroundColor: 'var(--dental-primary)', color: '#fff' }}
              >
                {category.name[language]}
              </Badge>
            )}

            {/* Product Name */}
            <h1
              className="text-2xl md:text-3xl font-bold text-foreground leading-tight"
              style={{
                fontFamily: isRTL
                  ? "var(--font-cairo), 'Cairo', sans-serif"
                  : "var(--font-syne), 'Syne', sans-serif",
              }}
            >
              {product.name[language]}
            </h1>

            {/* Brand + Model */}
            <p className="text-sm md:text-base text-muted-foreground">
              {t('products.brand')}: <span className="font-medium text-foreground">{product.brand}</span>
              <span className="mx-2">&middot;</span>
              {t('products.ref')}: <span className="font-medium text-foreground">{product.ref}</span>
            </p>

            {/* Availability Badge */}
            <Badge
              variant="outline"
              className={cn(
                'w-fit gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full',
                product.inStock
                  ? 'border-green-300 text-green-700 bg-green-50'
                  : 'border-red-300 text-red-600 bg-red-50'
              )}
            >
              <span
                className={cn(
                  'h-2 w-2 rounded-full',
                  product.inStock ? 'bg-green-500' : 'bg-red-500'
                )}
              />
              {product.inStock ? t('common.available') : t('common.unavailable')}
            </Badge>

            {/* Price */}
            <p
              className="text-2xl md:text-3xl font-bold"
              style={{ color: 'var(--dental-primary)' }}
            >
              {formatPrice(product.price, language)}
            </p>

            {/* Description */}
            <div
              className="prose prose-sm max-w-none text-foreground/80 leading-relaxed"
              dangerouslySetInnerHTML={{ __html: sanitizeHtml(product.description[language]) }}
            />

            {/* Feature Tags */}
            {product.features[language] && product.features[language].length > 0 && (
              <div className="flex flex-wrap gap-2">
                {product.features[language].map((feature, idx) => (
                  <Badge
                    key={idx}
                    variant="secondary"
                    className="text-xs font-normal px-2.5 py-1 rounded-md"
                  >
                    {feature}
                  </Badge>
                ))}
              </div>
            )}

            {/* Quick Info Row */}
            <div className="grid grid-cols-2 gap-3 mt-1">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Shield className="h-4 w-4" style={{ color: 'var(--dental-primary)' }} />
                <span>{t('productDetail.warranty')}: {product.warranty}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Truck className="h-4 w-4" style={{ color: 'var(--dental-primary)' }} />
                <span>{product.deliveryTime[language]}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Package className="h-4 w-4" style={{ color: 'var(--dental-primary)' }} />
                <span>
                  {t('productDetail.installation')}: {product.installationIncluded ? t('productDetail.yes') : t('productDetail.no')}
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <GraduationCap className="h-4 w-4" style={{ color: 'var(--dental-primary)' }} />
                <span>
                  {t('productDetail.training')}: {product.trainingIncluded ? t('productDetail.yes') : t('productDetail.no')}
                </span>
              </div>
            </div>

            {/* Detailed Product Info: SAV, Installation, Formation */}
            {product.productInfo && (
              <div className="mt-4 space-y-3">
                {/* SAV Info */}
                {(product.productInfo.sav_info_fr || product.productInfo.sav_info_ar) && (
                  <Card className="p-4 border-l-4" style={{ borderLeftColor: 'var(--dental-primary)' }}>
                    <div className="flex items-start gap-3">
                      <Headphones className="h-5 w-5 shrink-0 mt-0.5" style={{ color: 'var(--dental-primary)' }} />
                      <div>
                        <h4 className="font-semibold text-foreground text-sm mb-1">
                          {language === 'ar' ? 'خدمة ما بعد البيع' : 'Service Après-Vente (SAV)'}
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {language === 'ar'
                            ? (product.productInfo.sav_info_ar || product.productInfo.sav_info_fr)
                            : (product.productInfo.sav_info_fr || product.productInfo.sav_info_ar)}
                        </p>
                      </div>
                    </div>
                  </Card>
                )}

                {/* Installation Info */}
                {(product.productInfo.installation_info_fr || product.productInfo.installation_info_ar) && (
                  <Card className="p-4 border-l-4" style={{ borderLeftColor: 'var(--dental-primary)' }}>
                    <div className="flex items-start gap-3">
                      <Wrench className="h-5 w-5 shrink-0 mt-0.5" style={{ color: 'var(--dental-primary)' }} />
                      <div>
                        <h4 className="font-semibold text-foreground text-sm mb-1">
                          {language === 'ar' ? 'التركيب' : 'Installation'}
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {language === 'ar'
                            ? (product.productInfo.installation_info_ar || product.productInfo.installation_info_fr)
                            : (product.productInfo.installation_info_fr || product.productInfo.installation_info_ar)}
                        </p>
                      </div>
                    </div>
                  </Card>
                )}

                {/* Formation Info */}
                {(product.productInfo.formation_info_fr || product.productInfo.formation_info_ar) && (
                  <Card className="p-4 border-l-4" style={{ borderLeftColor: 'var(--dental-primary)' }}>
                    <div className="flex items-start gap-3">
                      <GraduationCap className="h-5 w-5 shrink-0 mt-0.5" style={{ color: 'var(--dental-primary)' }} />
                      <div>
                        <h4 className="font-semibold text-foreground text-sm mb-1">
                          {language === 'ar' ? 'التدريب' : 'Formation'}
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {language === 'ar'
                            ? (product.productInfo.formation_info_ar || product.productInfo.formation_info_fr)
                            : (product.productInfo.formation_info_fr || product.productInfo.formation_info_ar)}
                        </p>
                      </div>
                    </div>
                  </Card>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className={cn('flex items-center gap-3 mt-2', isRTL && 'flex-row-reverse')}>
              <Button
                variant="outline"
                size="lg"
                className="gap-2 rounded-lg"
                onClick={() => {
                  const pdfUrl = product.pdfUrl || product.brochurePdf;
                  if (pdfUrl) {
                    const url = pdfUrl.startsWith('http') ? pdfUrl : getPdfUrl(pdfUrl);
                    window.open(url, '_blank');
                  } else {
                    toast.info(language === 'ar' ? 'لا تتوفر وثائق لهذا المنتج بعد' : 'Aucun document disponible pour ce produit');
                  }
                }}
              >
                <FileDown className="h-4 w-4" />
                {t('productDetail.documents')}
              </Button>
              <Button
                size="lg"
                onClick={handleAddToQuote}
                className="gap-2 rounded-lg text-white flex-1"
                style={{ backgroundColor: 'var(--dental-primary)' }}
              >
                {isInCart(product.id) ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <ShoppingCart className="h-4 w-4" />
                )}
                {t('productDetail.addToCart')}
              </Button>
            </div>
            {/* Compare Button */}
            <Button
              variant={isInCompare(product.id) ? 'default' : 'outline'}
              size="lg"
              onClick={handleToggleCompare}
              disabled={!isInCompare(product.id) && maxCompareReached()}
              className={cn(
                'w-full gap-2 rounded-lg mt-1',
                isInCompare(product.id) && 'text-white',
              )}
              style={
                isInCompare(product.id)
                  ? { backgroundColor: 'var(--dental-primary)' }
                  : undefined
              }
            >
              <GitCompareArrows className="h-4 w-4" />
              {isInCompare(product.id)
                ? isRTL
                  ? 'في المقارنة'
                  : 'Dans le comparateur'
                : t('products.compare')}
            </Button>
          </motion.div>
        </div>

        {/* Specs Table */}
        {product.specs && product.specs.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="mt-12"
          >
            <Card className="overflow-hidden">
              <div className="p-5 md:p-6 border-b border-neutral-100">
                <h2
                  className="text-lg md:text-xl font-bold text-foreground"
                  style={{
                    fontFamily: isRTL
                      ? "var(--font-cairo), 'Cairo', sans-serif"
                      : "var(--font-syne), 'Syne', sans-serif",
                  }}
                >
                  {t('productDetail.specifications')}
                </h2>
              </div>
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableCell className="font-semibold text-foreground">
                      {t('products.features')}
                    </TableCell>
                    <TableCell className="font-semibold text-foreground">
                      {isRTL ? 'القيمة' : 'Valeur'}
                    </TableCell>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {product.specs.map((spec, idx) => (
                    <TableRow
                      key={idx}
                      className={cn(idx % 2 === 0 ? 'bg-white' : 'bg-muted/30')}
                    >
                      <TableCell className="font-medium text-foreground">
                        {spec.label[language]}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {spec.value}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </motion.div>
        )}

        {/* Videos Section */}
        {product.videos && product.videos.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.35 }}
            className="mt-12"
          >
            <ProductVideos videos={product.videos} />
          </motion.div>
        )}

        {/* Similar Products */}
        {relatedProducts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-12"
          >
            <h2
              className="text-lg md:text-xl font-bold text-foreground mb-6"
              style={{
                fontFamily: isRTL
                  ? "var(--font-cairo), 'Cairo', sans-serif"
                  : "var(--font-syne), 'Syne', sans-serif",
              }}
            >
              {t('productDetail.relatedProducts')}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {relatedProducts.map((rp) => (
                <motion.div
                  key={rp.id}
                  whileHover={{ y: -4 }}
                  transition={{ duration: 0.2 }}
                  className="group bg-white rounded-xl border border-neutral-100 overflow-hidden hover:shadow-lg hover:border-primary-200 transition-all duration-300 cursor-pointer"
                  onClick={() => {
                    setSelectedImage(0);
                    navigate(`/product/${rp.slug}`);
                  }}
                >
                  <div className="relative w-full" style={{ aspectRatio: '16/9' }}>
                    <img
                      src={rp.images[0]}
                      alt={rp.name[language]}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      onError={(e) => { const t = e.target as HTMLImageElement; t.src = `https://placehold.co/600x400/E2E8F0/64748B?text=${encodeURIComponent(rp.name[language]?.slice(0,30)||'Image')}`; }}
                    />
                    {category && (
                      <span
                        className="absolute top-3 start-3 text-white text-xs font-medium px-2.5 py-0.5 rounded-full"
                        style={{ backgroundColor: 'var(--dental-primary)' }}
                      >
                        {category.name[language]}
                      </span>
                    )}
                  </div>
                  <div className="p-4 flex flex-col gap-1.5">
                    <h3
                      className="font-semibold text-foreground text-sm leading-snug line-clamp-1"
                      style={{
                        fontFamily: isRTL
                          ? "var(--font-cairo), 'Cairo', sans-serif"
                          : "var(--font-syne), 'Syne', sans-serif",
                      }}
                    >
                      {rp.name[language]}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {rp.brand} &middot; {rp.ref}
                    </p>
                    <p
                      className="text-sm font-bold"
                      style={{ color: 'var(--dental-primary)' }}
                    >
                      {formatPrice(rp.price, language)}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>

      {/* Lightbox Dialog */}
      <Dialog open={lightboxOpen} onOpenChange={setLightboxOpen}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden bg-black border-none">
          <DialogTitle className="sr-only">
            {product.name[language]} - {t('productDetail.imageGallery')}
          </DialogTitle>
          <DialogDescription className="sr-only">
            {t('productDetail.imageGallery')}
          </DialogDescription>
          <div className="relative w-full" style={{ aspectRatio: '4/3' }}>
            <img
              src={images[selectedImage]}
              alt={product.name[language]}
              className="w-full h-full object-contain bg-neutral-950"
              onError={(e) => { const t = e.target as HTMLImageElement; t.src = `https://placehold.co/600x400/E2E8F0/64748B?text=${encodeURIComponent(product.name[language]?.slice(0,30)||'Image')}`; }}
            />
            {/* Thumbnail Navigation in Lightbox */}
            {images.length > 1 && (
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={cn(
                      'w-14 h-10 rounded-md overflow-hidden border-2 transition-all',
                      selectedImage === idx
                        ? 'border-white'
                        : 'border-white/30 hover:border-white/60'
                    )}
                  >
                    <img
                      src={img}
                      alt=""
                      className="w-full h-full object-cover"
                      onError={(e) => { const t = e.target as HTMLImageElement; t.src = `https://placehold.co/120x80/E2E8F0/64748B?text=...`; }}
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
