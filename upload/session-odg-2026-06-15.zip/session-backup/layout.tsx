import { Syne, DM_Sans, Cairo } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";

const syne = Syne({
  variable: "--font-syne",
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600", "700", "800"],
});

const dmSans = DM_Sans({
  variable: "--font-dm-sans",
  subsets: ["latin"],
  display: "swap",
  weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
});

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  display: "swap",
  weight: ["200", "300", "400", "500", "600", "700", "800", "900"],
});

export const metadata = {
  title: "OUADAH DENTAL GROUPE (ODG) — Équipements Dentaires Professionnels en Algérie",
  description: "OUADAH DENTAL GROUPE — Distributeur exclusif d'équipements dentaires professionnels en Algérie. Fauteuils, unités, radiologie, stérilisation. 48 wilayas, SAV réactif.",
  keywords: "équipement dentaire Algérie, fauteuil dentaire, unité dentaire, radiologie dentaire, stérilisation, ODG, OUADAH DENTAL GROUPE, matériel dentaire Oran",
  authors: [{ name: "OUADAH DENTAL GROUPE" }],
  robots: "index, follow",
  icons: {
    icon: [
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon.ico", sizes: "32x32" },
      { url: "/logo-odg.jpg", sizes: "192x192", type: "image/jpeg" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
  },
  openGraph: {
    title: "OUADAH DENTAL GROUPE — Équipements Dentaires Professionnels",
    description: "Distributeur exclusif d'équipements dentaires en Algérie. 48 wilayas, SAV réactif, installation et formation incluses.",
    type: "website",
    locale: "fr_DZ",
    alternateLocale: "ar_DZ",
    siteName: "OUADAH DENTAL GROUPE",
  },
  twitter: {
    card: "summary_large_image",
    title: "OUADAH DENTAL GROUPE — Équipements Dentaires",
    description: "Distributeur exclusif d'équipements dentaires en Algérie. 48 wilayas, SAV réactif.",
  },
  other: {
    "theme-color": "#1E3A5F",
  },
  alternates: {
    canonical: "https://ouadah-dental-groupe.vercel.app",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${syne.variable} ${dmSans.variable} ${cairo.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
