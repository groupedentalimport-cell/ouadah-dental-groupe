export interface Category {
  slug: string;
  name: { fr: string; ar: string };
  description: { fr: string; ar: string };
  icon: string;
  count: number;
  image: string;
}

export interface ProductSpec {
  label: { fr: string; ar: string };
  value: string;
}

export interface Product {
  id: string;
  slug: string;
  name: { fr: string; ar: string };
  description: { fr: string; ar: string };
  shortDescription: { fr: string; ar: string };
  category: string;
  price: number;
  images: string[];
  specs: ProductSpec[];
  features: { fr: string[]; ar: string[] };
  inStock: boolean;
  isFeatured: boolean;
  isNew: boolean;
  isBestSeller: boolean;
  brand: string;
  origin: string;
  warranty: string;
  deliveryTime: { fr: string; ar: string };
  installationIncluded: boolean;
  trainingIncluded: boolean;
  ref: string;
  target: string[]; // cible: ['Clinique', 'Revendeur', 'Comptoir']
  pdfUrl?: string; // fiche technique PDF
  brochurePdf?: string; // brochure PDF
  videos?: { title: { fr: string; ar: string }; url: string; type: 'youtube' | 'vimeo' }[];
  productInfo?: Record<string, string>; // Extended product info (SAV, installation, formation details)
}

export interface BlogPost {
  id: string;
  slug: string;
  title: { fr: string; ar: string };
  excerpt: { fr: string; ar: string };
  content: { fr: string; ar: string };
  image: string;
  author: string;
  date: string;
  readTime: number;
  tags: string[];
  category: string;
}

export interface ContactInfo {
  address: { fr: string; ar: string };
  phone: string;
  email: string;
  whatsapp: string;
  hours: { fr: string; ar: string };
  city: { fr: string; ar: string };
  wilaya: { fr: string; ar: string };
  social: {
    facebook: string;
    instagram: string;
    linkedin: string;
    youtube: string;
  };
}

// ============================================================
// CATEGORIES
// ============================================================
export const categories: Category[] = [
  {
    slug: 'fauteuil-dentaire',
    name: { fr: 'Fauteuils Dentaires', ar: 'كراسي طب الأسنان' },
    description: {
      fr: 'Fauteuils ergonomiques de dernière génération pour un confort optimal du patient et du praticien. Nos fauteuils intègrent les dernières technologies pour une pratique dentaire moderne et efficace.',
      ar: 'كراسي مريحة من الجيل الأخير لضمان راحة مثالية للمريض والطبيب. تدمج كراسينا أحدث التقنيات لممارسة طب أسنان حديثة وفعالة.',
    },
    icon: 'Armchair',
    count: 12,
    image: 'https://placehold.co/600x400/2563EB/FFFFFF?text=Fauteuil+Dentaire',
  },
  {
    slug: 'unit-dentaire',
    name: { fr: 'Unités Dentaires', ar: 'وحدات طب الأسنان' },
    description: {
      fr: 'Unités de soins complètes et modulaires adaptées à tous les cabinets dentaires. Configurez votre unité selon vos besoins spécifiques avec nos options personnalisables.',
      ar: 'وحدات علاجية كاملة ومعيارية تناسب جميع عيادات طب الأسنان. خصّصوا وحدتكم حسب احتياجاتكم الخاصة بخياراتنا القابلة للتخصيص.',
    },
    icon: 'Monitor',
    count: 8,
    image: 'https://placehold.co/600x400/0EA5E9/FFFFFF?text=Unit+Dentaire',
  },
  {
    slug: 'radiologie',
    name: { fr: 'Radiologie', ar: 'الأشعة' },
    description: {
      fr: 'Équipements de radiologie numérique pour un diagnostic précis et rapide. Réduisez l\'exposition aux rayons X tout en obtenant des images d\'une qualité exceptionnelle.',
      ar: 'معدات أشعة رقمية لتشخيص دقيق وسريع. قلّلوا التعرض للأشعة السينية مع الحصول على صور بجودة استثنائية.',
    },
    icon: 'Scan',
    count: 6,
    image: 'https://placehold.co/600x400/10B981/FFFFFF?text=Radiologie',
  },
  {
    slug: 'sterilisation',
    name: { fr: 'Stérilisation', ar: 'التعقيم' },
    description: {
      fr: 'Autoclaves et stérilisateurs professionnels pour une hygiène irréprochable. Conformité aux normes internationales les plus strictes pour la sécurité de vos patients.',
      ar: 'أوتوكلاف ومعقمات احترافية لنظافة لا تشوبها شائبة. التوافق مع أ صار المعايير الدولية لسلامة مرضاكم.',
    },
    icon: 'ShieldCheck',
    count: 10,
    image: 'https://placehold.co/600x400/F59E0B/FFFFFF?text=Sterilisation',
  },
];

// ============================================================
// PRODUCTS
// ============================================================
export const products: Product[] = [
  {
    id: '1',
    slug: 'fauteuil-dentaire-prestige-x500',
    name: { fr: 'Fauteuil Dentaire Prestige X500', ar: 'كرسي أسنان بريستيج X500' },
    description: {
      fr: 'Le fauteuil Prestige X500 représente l\'excellence en matière de confort dentaire. Doté d\'un moteur silencieux, d\'un dossier articulé à 6 positions et d\'un plateau instrumental intégré, il offre une expérience de soins incomparable. Son design ergonomique réduit la fatigue du praticien tout en assurant un confort maximal pour le patient. Le revêtement en cuir synthétique de grade médical garantit une hygiène parfaite et une durabilité exceptionnelle.',
      ar: 'يمثل كرسي بريستيج X500 التميز في مجال راحة طب الأسنان. مزود بمحرك هادئ، ومسند ظهر مفصلي بـ 6 وضعيات وصينية أدوات مدمجة، يوفر تجربة علاجية لا مثيل لها. يقلل تصميمه المريح من إرهاق الطبيب مع ضمان أقصى راحة للمريض. الغلاف الجلدي الاصطناعي من الدرجة الطبية يضمن نظافة مثالية ومتانة استثنائية.',
    },
    shortDescription: {
      fr: 'Fauteuil dentaire haut de gamme avec moteur silencieux et plateau instrumental intégré',
      ar: 'كرسي أسنان راقي بمحرك هادئ وصينية أدوات مدمجة',
    },
    category: 'fauteuil-dentaire',
    price: 2850000,
    images: [
      'https://placehold.co/600x400/2563EB/FFFFFF?text=Prestige+X500',
      'https://placehold.co/600x400/1D4ED8/FFFFFF?text=X500+Side',
      'https://placehold.co/600x400/1E40AF/FFFFFF?text=X500+Detail',
    ],
    specs: [
      { label: { fr: 'Poids maximal patient', ar: 'الوزن الأقصى للمريض' }, value: '200 kg' },
      { label: { fr: 'Vitesse de rotation', ar: 'سرعة الدوران' }, value: '40 000 tr/min' },
      { label: { fr: 'Nombre de positions', ar: 'عدد الوضعيات' }, value: '6 positions' },
      { label: { fr: 'Alimentation', ar: 'الطاقة' }, value: '220V / 50Hz' },
      { label: { fr: 'Niveau sonore', ar: 'مستوى الضوضاء' }, value: '< 45 dB' },
      { label: { fr: 'Dimensions', ar: 'الأبعاد' }, value: '185 x 80 x 130 cm' },
    ],
    features: {
      fr: [
        'Mètre silencieux haute performance',
        'Dossier articulé 6 positions',
        'Plateau instrumental LED intégré',
        'Système d\'aspiration central',
        'Commandes au pied sans fil',
        'Revêtement cuir médical',
        'Appuie-tête adjustable',
      ],
      ar: [
        'محرك عالي الأداء هادئ',
        'مسند ظهر مفصلي بـ 6 وضعيات',
        'صينية أدوات LED مدمجة',
        'نظام شفط مركزي',
        'أوامر قدم لاسلكية',
        'غلاف جلدي طبي',
        'مسند رأس قابل للتعديل',
      ],
    },
    inStock: true,
    isFeatured: true,
    isNew: true,
    isBestSeller: true,
    brand: 'DentaLine',
    origin: 'Allemagne',
    warranty: '5 ans',
    deliveryTime: { fr: '3-4 semaines', ar: '3-4 أسابيع' },
    installationIncluded: true,
    trainingIncluded: true,
    ref: 'DL-FDX500',
    target: ['Clinique', 'Revendeur'],
    pdfUrl: '',
    brochurePdf: '',
    videos: [
      {
        title: { fr: 'Démonstration du Fauteuil Prestige X500', ar: 'عرض توضيحي لكرسي بريستيج X500' },
        url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        type: 'youtube',
      },
    ],
  },
  {
    id: '2',
    slug: 'fauteuil-dentaire-ergo-pro-300',
    name: { fr: 'Fauteuil Dentaire Ergo Pro 300', ar: 'كرسي أسنان إرغو برو 300' },
    description: {
      fr: 'L\'Ergo Pro 300 combine ergonomie avancée et technologie de pointe. Parfaitement adapté aux cabinets modernes, il dispose d\'un écran tactile de contrôle, d\'un éclairage LED optimisé et d\'un système de positionnement automatique. Son design compact optimise l\'espace de travail tout en offrant toutes les fonctionnalités nécessaires.',
      ar: 'يجمع إرغو برو 300 بين الراحة المتقدمة والتكنولوجيا الرائدة. متكيف تماماً مع العيادات الحديثة، يتميز بشاشة تحكم تعمل باللمس، وإضاءة LED محسنة ونظام تموضع آلي. تصميمه المدمج يحسن مساحة العمل مع توفير جميع الوظائف اللازمة.',
    },
    shortDescription: {
      fr: 'Fauteuil ergonomique avec écran tactile et éclairage LED optimisé',
      ar: 'كرسي مريح بشاشة لمس وإضاءة LED محسنة',
    },
    category: 'fauteuil-dentaire',
    price: 1950000,
    images: [
      'https://placehold.co/600x400/0EA5E9/FFFFFF?text=Ergo+Pro+300',
      'https://placehold.co/600x400/0284C7/FFFFFF?text=ErgoPro+Side',
    ],
    specs: [
      { label: { fr: 'Poids maximal patient', ar: 'الوزن الأقصى للمريض' }, value: '180 kg' },
      { label: { fr: 'Écran de contrôle', ar: 'شاشة التحكم' }, value: '7 pouces tactile' },
      { label: { fr: 'Éclairage', ar: 'الإضاءة' }, value: 'LED 20 000 lux' },
      { label: { fr: 'Alimentation', ar: 'الطاقة' }, value: '220V / 50Hz' },
      { label: { fr: 'Dimensions', ar: 'الأبعاد' }, value: '175 x 75 x 125 cm' },
    ],
    features: {
      fr: [
        'Écran tactile 7 pouces',
        'Éclairage LED 20 000 lux',
        'Positionnement automatique',
        'Design compact',
        'Programmation 4 positions mémoire',
      ],
      ar: [
        'شاشة لمس 7 بوصات',
        'إضاءة LED 20 000 لوكس',
        'تموضع آلي',
        'تصميم مدمج',
        'برمجة 4 وضعيات ذاكرة',
      ],
    },
    inStock: true,
    isFeatured: true,
    isNew: false,
    isBestSeller: true,
    brand: 'MediChair',
    origin: 'Italie',
    warranty: '3 ans',
    deliveryTime: { fr: '2-3 semaines', ar: '2-3 أسابيع' },
    installationIncluded: true,
    trainingIncluded: true,
    ref: 'MC-EP300',
    target: ['Clinique', 'Comptoir'],
    pdfUrl: '',
    brochurePdf: '',
    videos: [
      {
        title: { fr: 'Tutoriel Fauteuil Ergo Pro 300', ar: 'دليل تعليمي لكرسي إرغو برو 300' },
        url: 'https://www.youtube.com/watch?v=ScMzIvxBSi4',
        type: 'youtube',
      },
    ],
  },
  {
    id: '3',
    slug: 'unit-dentaire-complete-smile-800',
    name: { fr: 'Unit Dentaire Complète Smile 800', ar: 'وحدة أسنان كاملة سمايل 800' },
    description: {
      fr: 'L\'unit Smile 800 est la solution complète pour votre cabinet dentaire. Elle intègre un fauteuil, un plateau instrumental avec 5 positions, un crachoir céramique, une lampe LED et un système d\'aspiration puissant. Modulaire et personnalisable, elle s\'adapte à toutes les configurations de cabinet et à tous les budgets.',
      ar: 'وحدة سمايل 800 هي الحل الكامل لعيادتكم. تدمج كرسياً، وصينية أدوات بـ 5 وضعيات، وبصاق خزفي، ومصباح LED ونظام شفط قوي. معيارية وقابلة للتخصيص، تتكيف مع جميع تهيئات العيادات وجميع الميزانيات.',
    },
    shortDescription: {
      fr: 'Unité dentaire complète modulaire avec 5 positions instrumentales',
      ar: 'وحدة أسنان كاملة معيارية بـ 5 وضعيات أدوات',
    },
    category: 'unit-dentaire',
    price: 3500000,
    images: [
      'https://placehold.co/600x400/10B981/FFFFFF?text=Smile+800',
      'https://placehold.co/600x400/059669/FFFFFF?text=Smile800+Side',
      'https://placehold.co/600x400/047857/FFFFFF?text=Smile800+Top',
    ],
    specs: [
      { label: { fr: 'Positions instrumentales', ar: 'وضعيات الأدوات' }, value: '5 positions' },
      { label: { fr: 'Type de crachoir', ar: 'نوع البصاق' }, value: 'Céramique' },
      { label: { fr: 'Système d\'aspiration', ar: 'نظام الشفط' }, value: 'Central haute puissance' },
      { label: { fr: 'Lampe', ar: 'المصباح' }, value: 'LED 25 000 lux' },
      { label: { fr: 'Alimentation', ar: 'الطاقة' }, value: '220V / 50Hz' },
      { label: { fr: 'Dimensions', ar: 'الأبعاد' }, value: '210 x 90 x 140 cm' },
    ],
    features: {
      fr: [
        'Plateau instrumental 5 positions',
        'Crachoir céramique avec chauffage',
        'Lampe LED 25 000 lux',
        'Aspiration centrale haute puissance',
        'Système de commande pneumatique',
        'Tablette patiente amovible',
      ],
      ar: [
        'صينية أدوات بـ 5 وضعيات',
        'بصاق خزفي مع تدفئة',
        'مصباح LED 25 000 لوكس',
        'شفط مركزي عالي القدرة',
        'نظام تحكم هوائي',
        'لوحة مريض قابلة للإزالة',
      ],
    },
    inStock: true,
    isFeatured: true,
    isNew: true,
    isBestSeller: false,
    brand: 'DentaLine',
    origin: 'Allemagne',
    warranty: '5 ans',
    deliveryTime: { fr: '4-6 semaines', ar: '4-6 أسابيع' },
    installationIncluded: true,
    trainingIncluded: true,
    ref: 'DL-SM800',
    target: ['Clinique', 'Revendeur', 'Comptoir'],
    pdfUrl: '',
    brochurePdf: '',
    videos: [
      {
        title: { fr: 'Démonstration Unit Smile 800', ar: 'عرض توضيحي لوحدة سمايل 800' },
        url: 'https://www.youtube.com/watch?v=5qap5aO4i9A',
        type: 'youtube',
      },
      {
        title: { fr: 'Tutoriel de configuration Smile 800', ar: 'دليل تعليمي لإعداد سمايل 800' },
        url: 'https://www.youtube.com/watch?v=jNQXAC9IVRw',
        type: 'youtube',
      },
    ],
  },
  {
    id: '4',
    slug: 'radio-digitale-periapical-xr200',
    name: { fr: 'Radio Digitale Périapicale XR200', ar: 'جهاز أشعة رقمية محيطية XR200' },
    description: {
      fr: 'Le XR200 est un capteur d\'imagerie numérique périapicale de dernière génération. Avec sa résolution exceptionnelle de 25 lp/mm et son exposition réduite de 70%, il permet un diagnostic précis tout en protégeant vos patients. Compatible avec tous les logiciels de gestion dentaire, il s\'intègre parfaitement dans votre flux de travail existant.',
      ar: 'XR200 هو جهاز تصوير رقمي محيطي من الجيل الأخير. بدقته الاستثنائية 25 زوج خط/مم وانخفاض التعرض بنسبة 70%، يسمح بتشخيص دقيق مع حماية مرضاكم. متوافق مع جميع برامج إدارة طب الأسنان، يندمج بسلاسة في سير عملكم الحالي.',
    },
    shortDescription: {
      fr: 'Capteur d\'imagerie numérique haute résolution avec réduction d\'exposition 70%',
      ar: 'جهاز تصوير رقمي عالي الدقة مع انخفاض التعرض بنسبة 70%',
    },
    category: 'radiologie',
    price: 890000,
    images: [
      'https://placehold.co/600x400/8B5CF6/FFFFFF?text=XR200',
      'https://placehold.co/600x400/7C3AED/FFFFFF?text=XR200+Screen',
    ],
    specs: [
      { label: { fr: 'Résolution', ar: 'الدقة' }, value: '25 lp/mm' },
      { label: { fr: 'Taille du capteur', ar: 'حجم المستشعر' }, value: '30 x 22 mm' },
      { label: { fr: 'Réduction d\'exposition', ar: 'تقليل التعرض' }, value: '70%' },
      { label: { fr: 'Temps d\'acquisition', ar: 'وقت الاستحواذ' }, value: '< 5 secondes' },
      { label: { fr: 'Connectivité', ar: 'الاتصال' }, value: 'USB 3.0 / WiFi' },
      { label: { fr: 'Compatibilité', ar: 'التوافق' }, value: 'DICOM 3.0' },
    ],
    features: {
      fr: [
        'Résolution ultra-haute 25 lp/mm',
        'Réduction d\'exposition 70%',
        'Acquisition en moins de 5 secondes',
        'Compatible DICOM 3.0',
        'Connectivité USB 3.0 et WiFi',
        'Logiciel d\'analyse intégré',
      ],
      ar: [
        'دقة فائقة 25 زوج خط/مم',
        'انخفاض التعرض بنسبة 70%',
        'استحواذ في أقل من 5 ثوانٍ',
        'متوافق مع DICOM 3.0',
        'اتصال USB 3.0 و WiFi',
        'برنامج تحليل مدمج',
      ],
    },
    inStock: true,
    isFeatured: true,
    isNew: false,
    isBestSeller: true,
    brand: 'RadioDent',
    origin: 'Corée du Sud',
    warranty: '3 ans',
    deliveryTime: { fr: '2-3 semaines', ar: '2-3 أسابيع' },
    installationIncluded: true,
    trainingIncluded: true,
    ref: 'RD-XR200',
    target: ['Clinique', 'Revendeur'],
    pdfUrl: '',
    brochurePdf: '',
    videos: [
      {
        title: { fr: 'Démonstration Radio XR200', ar: 'عرض توضيحي لجهاز أشعة XR200' },
        url: 'https://www.youtube.com/watch?v=9bZkp7q19f0',
        type: 'youtube',
      },
    ],
  },
  {
    id: '5',
    slug: 'autoclave-classe-b-steril-pro-23l',
    name: { fr: 'Autoclave Classe B Stéril Pro 23L', ar: 'أوتوكلاف فئة B ستريل برو 23 لتر' },
    description: {
      fr: 'L\'autoclave Stéril Pro 23L est un stérilisateur de Classe B, la norme la plus élevée en matière de stérilisation dentaire. Avec sa chambre de 23 litres, il peut traiter tous les types d\'instruments, y compris les instruments creux et emballés. Son cycle de stérilisation à 134°C garantit l\'élimination de tous les micro-organismes, y compris les prions.',
      ar: 'الأوتوكلاف ستريل برو 23 لتر هو معقم من الفئة B، أعلى معيار في مجال تعقيم طب الأسنان. بغرفته سعة 23 لتر، يمكنه معالجة جميع أنواع الأدوات، بما في ذلك الأدوات المجوفة والمغلقة. دورة التعقيم على 134 درجة مئوية تضمن القضاء على جميع الكائنات الدقيقة، بما في ذلك البريونات.',
    },
    shortDescription: {
      fr: 'Stérilisateur Classe B 23 litres avec cycle 134°C et traçabilité complète',
      ar: 'معقم فئة B سعة 23 لتر بدورة 134 درجة وتتبع كامل',
    },
    category: 'sterilisation',
    price: 1250000,
    images: [
      'https://placehold.co/600x400/F59E0B/FFFFFF?text=Steril+Pro+23L',
      'https://placehold.co/600x400/D97706/FFFFFF?text=SterilPro+Open',
    ],
    specs: [
      { label: { fr: 'Classe', ar: 'الفئة' }, value: 'Classe B (EN 13060)' },
      { label: { fr: 'Capacité', ar: 'السعة' }, value: '23 litres' },
      { label: { fr: 'Température max', ar: 'درجة الحرارة القصوى' }, value: '134°C' },
      { label: { fr: 'Temps de cycle', ar: 'مدة الدورة' }, value: '30-45 min' },
      { label: { fr: 'Système de séchage', ar: 'نظام التجفيف' }, value: 'Vacuum drying' },
      { label: { fr: 'Imprimante', ar: 'الطابعة' }, value: 'Intégrée' },
    ],
    features: {
      fr: [
        'Conforme EN 13060 Classe B',
        'Chambre 23 litres inox 316L',
        'Cycle 134°C avec séchage sous vide',
        'Imprimante intégrée pour traçabilité',
        'Écran LCD de contrôle',
        '6 programmes prédéfinis',
        'Système de sécurité anti-surchauffe',
      ],
      ar: [
        'متوافق مع EN 13060 فئة B',
        'غرفة 23 لتر ستانلس ستيل 316L',
        'دورة 134 درجة مع تجفيف بالتفريغ',
        'طابعة مدمجة للتتبع',
        'شاشة LCD للتحكم',
        '6 برامج مسبقة الإعداد',
        'نظام أمان ضد ارتفاع الحرارة',
      ],
    },
    inStock: true,
    isFeatured: true,
    isNew: true,
    isBestSeller: false,
    brand: 'SteriMed',
    origin: 'Turquie',
    warranty: '2 ans',
    deliveryTime: { fr: '1-2 semaines', ar: '1-2 أسبوع' },
    installationIncluded: true,
    trainingIncluded: true,
    ref: 'SM-SP23L',
    target: ['Clinique', 'Comptoir'],
    pdfUrl: '',
    brochurePdf: '',
    videos: [
      {
        title: { fr: 'Tutoriel Autoclave Stéril Pro 23L', ar: 'دليل تعليمي لأوتوكلاف ستريل برو 23 لتر' },
        url: 'https://www.youtube.com/watch?v=kJQP7kiw5Fk',
        type: 'youtube',
      },
    ],
  },
  {
    id: '6',
    slug: 'panoramique-3d-denta-scan-ct',
    name: { fr: 'Panoramique 3D DentaScan CT', ar: 'بانورامي ثلاثي الأبعاد دينتا سكان CT' },
    description: {
      fr: 'Le DentaScan CT est un système d\'imagerie panoramique et CBCT 3D de pointe. Avec un champ de vision allant jusqu\'à 16x13 cm et une résolution voxel de 75 μm, il offre une qualité d\'image exceptionnelle pour la planification implantaire, l\'orthodontie et la chirurgie maxillo-faciale. Son design compact et sa faible empreinte au sol le rendent idéal pour les cabinets de taille moyenne.',
      ar: 'دينتا سكان CT هو نظام تصوير بانورامي و CBCT ثلاثي الأبعاد متقدم. بمجال رؤية يصل إلى 16×13 سم ودقة فوكسل 75 ميكرومتر، يوفر جودة صور استثنائية لتخطيط الزرع، تقويم الأسنان وجراحة الوجه والفكين. تصميمه المدمج وبصمته الأرضية المنخفضة يجعلانه مثالياً للعيادات المتوسطة.',
    },
    shortDescription: {
      fr: 'Système panoramique et CBCT 3D avec résolution voxel 75μm',
      ar: 'نظام بانورامي و CBCT ثلاثي الأبعاد بدقة فوكسل 75 ميكرومتر',
    },
    category: 'radiologie',
    price: 6500000,
    images: [
      'https://placehold.co/600x400/6366F1/FFFFFF?text=DentaScan+CT',
      'https://placehold.co/600x400/4F46E5/FFFFFF?text=DentaScan+3D',
      'https://placehold.co/600x400/4338CA/FFFFFF?text=DentaScan+Screen',
    ],
    specs: [
      { label: { fr: 'Type', ar: 'النوع' }, value: 'Pano + CBCT 3D' },
      { label: { fr: 'FOV maximum', ar: 'مجال الرؤية الأقصى' }, value: '16 x 13 cm' },
      { label: { fr: 'Résolution voxel', ar: 'دقة الفوكسل' }, value: '75 μm' },
      { label: { fr: 'Temps d\'acquisition', ar: 'وقت الاستحواذ' }, value: '8-24 secondes' },
      { label: { fr: 'Tension', ar: 'الجهد' }, value: '60-90 kVp' },
      { label: { fr: 'Empreinte au sol', ar: 'البصمة الأرضية' }, value: '130 x 145 cm' },
    ],
    features: {
      fr: [
        'Imagerie panoramique et CBCT 3D',
        'Résolution voxel 75 μm',
        'FOV jusqu\'à 16x13 cm',
        'Acquisition rapide 8-24 secondes',
        'Faible dose d\'irradiation',
        'Logiciel de planification implantaire',
        'Compatible DICOM 3.0',
        'Design compact empreinte réduite',
      ],
      ar: [
        'تصوير بانورامي و CBCT ثلاثي الأبعاد',
        'دقة فوكسل 75 ميكرومتر',
        'مجال رؤية حتى 16×13 سم',
        'استحواذ سريع 8-24 ثانية',
        'جرعة إشعاع منخفضة',
        'برنامج تخطيط زراعة الأسنان',
        'متوافق مع DICOM 3.0',
        'تصميم مدمج بصمة منخفضة',
      ],
    },
    inStock: false,
    isFeatured: true,
    isNew: true,
    isBestSeller: false,
    brand: 'RadioDent',
    origin: 'Corée du Sud',
    warranty: '5 ans',
    deliveryTime: { fr: '6-8 semaines', ar: '6-8 أسابيع' },
    installationIncluded: true,
    trainingIncluded: true,
    ref: 'RD-DSCT',
    target: ['Clinique'],
    pdfUrl: '',
    brochurePdf: '',
    videos: [
      {
        title: { fr: 'Démonstration DentaScan CT 3D', ar: 'عرض توضيحي لدينتا سكان CT ثلاثي الأبعاد' },
        url: 'https://www.youtube.com/watch?v=OPf0YbXqDm0',
        type: 'youtube',
      },
      {
        title: { fr: 'Tutoriel imagerie panoramique DentaScan', ar: 'دليل تعليمي للتصوير البانورامي دينتا سكان' },
        url: 'https://www.youtube.com/watch?v=RgKAFK5djSk',
        type: 'youtube',
      },
    ],
  },
];

// ============================================================
// BLOG POSTS
// ============================================================
export const blogPosts: BlogPost[] = [
  {
    id: '1',
    slug: 'tendances-equipements-dentaires-2024',
    title: {
      fr: 'Les Tendances en Équipements Dentaires pour 2024',
      ar: 'اتجاهات معدات طب الأسنان لعام 2024',
    },
    excerpt: {
      fr: 'Découvrez les innovations technologiques qui transforment la pratique dentaire en 2024 : intelligence artificielle, imagerie 3D, fauteuils connectés et plus encore.',
      ar: 'اكتشفوا الابتكارات التكنولوجية التي تحول ممارسة طب الأسنان في 2024: الذكاء الاصطناعي، التصوير ثلاثي الأبعاد، الكراسي المتصلة والمزيد.',
    },
    content: {
      fr: `<h2>L'intelligence artificielle au service du diagnostic</h2>
<p>L'IA révolutionne le diagnostic dentaire en permettant la détection précoce des caries, des lésions périapicales et des anomalies osseuses. Les algorithmes d'apprentissage profond atteignent désormais des taux de précision supérieurs à 95%, surpassant parfois les cliniciens expérimentés dans la détection de lésions subtiles.</p>

<h2>L'imagerie CBCT 3D devient la norme</h2>
<p>La tomographie volumique à faisceau conique (CBCT) s'impose comme l'outil d'imagerie de référence en dentisterie. Les nouveaux systèmes offrent des résolutions inférieures à 100 microns avec des doses d'irradiation toujours plus faibles. Cette technologie est désormais indispensable pour la planification implantaire, l'orthodontie et la chirurgie maxillo-faciale.</p>

<h2>Les fauteuils dentaires connectés</h2>
<p>Les fauteuils de nouvelle génération intègrent des capteurs IoT qui permettent le suivi en temps réel de l'utilisation, la maintenance prédictive et l'optimisation des protocoles de soin. Ces données aident les praticiens à améliorer leur efficacité et à réduire les temps d'arrêt.</p>

<h2>Stérilisation et traçabilité renforcées</h2>
<p>Les nouveaux autoclaves de Classe B offrent une traçabilité complète du cycle de stérilisation, conforme aux normes EN 13060 et ISO 11607. L'intégration de puces RFID dans les plateaux d'instruments permet un suivi individualisé de chaque instrument.</p>`,
      ar: `<h2>الذكاء الاصطناعي في خدمة التشخيص</h2>
<p>يثور الذكاء الاصطناعي تشخيص طب الأسنان من خلال السماح بالكشف المبكر عن التسوس والآفات المحيطية والشذوذ العظمي. تصل خوارزميات التعلم العميق الآن إلى معدلات دقة تتجاوز 95%، متفوقة أحياناً على الأطباء ذوي الخبرة في الكشف عن الآفات الدقيقة.</p>

<h2>التصوير CBCT ثلاثي الأبعاد يصبح المعيار</h2>
<p>تفرض طبقة شعاع الحزمة المخروطية (CBCT) نفسها كأداة تصوير مرجعية في طب الأسنان. توفر الأنظمة الجديدة دقة أقل من 100 ميكرون مع جرعات إشعاع منخفضة باستمرار. أصبحت هذه التقنية ضرورية الآن لتخطيط الزراعة، تقويم الأسنان وجراحة الوجه والفكين.</p>

<h2>كراسي أسنان متصلة</h2>
<p>تدمج كراسي الجيل الجديد مستشعرات IoT تسمح بالمتابعة في الوقت الحقيقي للاستخدام، الصيانة التنبؤية وتحسين بروتوكولات العلاج. تساعد هذه البيانات الممارسين على تحسين كفاءتهم وتقليل أوقات التوقف.</p>

<h2>التعقيم والتتبع المعزز</h2>
<p>توفر الأوتوكلافات الجديدة من الفئة B تتبعاً كاملاً لدورة التعقيم، متوافقة مع معايير EN 13060 و ISO 11607. يسمح دمج شرائح RFID في صواني الأدوات بالمتابعة الفردية لكل أداة.</p>`,
    },
    image: 'https://placehold.co/800x400/2563EB/FFFFFF?text=Tendances+2024',
    author: 'Dr. Karim Benali',
    date: '2024-03-15',
    readTime: 6,
    tags: ['technologie', 'innovation', 'IA', 'CBCT'],
    category: 'technologie',
  },
  {
    id: '2',
    slug: 'guide-choisir-autoclave-cabinet-dentaire',
    title: {
      fr: 'Guide Complet pour Choisir un Autoclave pour votre Cabinet Dentaire',
      ar: 'دليل شامل لاختيار أوتوكلاف لعيادة طب الأسنان',
    },
    excerpt: {
      fr: 'Tout ce que vous devez savoir pour choisir le bon autoclave : Classe B vs Classe S, capacité, fonctionnalités et normes de conformité.',
      ar: 'كل ما تحتاج معرفته لاختيار الأوتوكلاف المناسب: الفئة B مقابل الفئة S، السعة، الميزات ومعايير التوافق.',
    },
    content: {
      fr: `<h2>Classe B vs Classe S : Quelle différence ?</h2>
<p>Les autoclaves de Classe B sont les seuls à garantir une stérilisation conforme pour TOUS les types d'instruments, y compris les instruments creux et emballés. Ils utilisent un système de pré-vide fractionné qui élimine l'air résiduel de la chambre, assurant une pénétration optimale de la vapeur.</p>
<p>Les autoclaves de Classe S sont adaptés aux instruments pleins non emballés. Ils sont moins chers mais ne conviennent pas à tous les types d'instruments dentaires.</p>

<h2>Quelle capacité choisir ?</h2>
<p>Pour un cabinet de 1 à 2 fauteuils, une capacité de 17 à 23 litres est généralement suffisante. Pour les cabinets plus importants ou les centres de soins, privilégiez une capacité de 28 à 45 litres pour optimiser les cycles de stérilisation.</p>

<h2>Les fonctionnalités essentielles</h2>
<p>Vérifiez que votre autoclave dispose au minimum de : un système de séchage sous vide, une imprimante intégrée pour la traçabilité, un écran de contrôle LCD, et au moins 4 programmes prédéfinis (134°C emballé, 134°C non emballé, 121°C, programme prion).</p>

<h2>Conformité et normes</h2>
<p>Assurez-vous que votre autoclave est conforme à la norme EN 13060 et dispose du marquage CE médical. En Algérie, la conformité aux normes du Ministère de la Santé est obligatoire.</p>`,
      ar: `<h2>الفئة B مقابل الفئة S: ما الفرق؟</h2>
<p>أوتوكلافات الفئة B هي الوحيدة التي تضمن تعقيماً متوافقاً لجميع أنواع الأدوات، بما في ذلك الأدوات المجوفة والمغلقة. تستخدم نظام تفريغ مسبق مجزأ يزيل الهواء المتبقي من الغرفة، مما يضمن اختراقاً مثالياً للبخار.</p>
<p>أوتوكلافات الفئة S مناسبة للأدوات المصمتة غير المغلفة. هي أرخص لكنها لا تناسب جميع أنواع أدوات طب الأسنان.</p>

<h2>أي سعة تختارون؟</h2>
<p>لعيادة من 1 إلى 2 كراسي، سعة 17 إلى 23 لتر عادة ما تكون كافية. للعيادات الأكبر أو مراكز العلاج، فضّلوا سعة 28 إلى 45 لتر لتحسين دورات التعقيم.</p>

<h2>الميزات الأساسية</h2>
<p>تحققوا من أن أوتوكلافكم يتوفر على الأقل على: نظام تجفيف بالتفريغ، طابعة مدمجة للتتبع، شاشة تحكم LCD، و4 برامج مسبقة الإعداد على الأقل (134 درجة مغلّف، 134 درجة غير مغلّف، 121 درجة، برنامج البريونات).</p>

<h2>التوافق والمعايير</h2>
<p>تأكدوا من أن أوتوكلافكم متوافق مع معيار EN 13060 ويحمل علامة CE الطبية. في الجزائر، التوافق مع معايير وزارة الصحة إلزامي.</p>`,
    },
    image: 'https://placehold.co/800x400/F59E0B/FFFFFF?text=Guide+Autoclave',
    author: 'Dr. Samira Hadj',
    date: '2024-02-28',
    readTime: 8,
    tags: ['sterilisation', 'guide', 'autoclave', 'conformite'],
    category: 'guide',
  },
];

// ============================================================
// CONTACT INFO
// ============================================================
export const contactInfo: ContactInfo = {
  address: {
    fr: 'Coopérative Azzouz Abdelkader, N°45, Commune d\'Es-Senia, Oran, Algérie',
    ar: 'تعاونية عزوز عبد القادر، رقم 45، بلدية السانية، وهران، الجزائر',
  },
  phone: '0771 88 89 48',
  email: 'groupedentalimport@gmail.com',
  whatsapp: '+213 771 88 89 48',
  hours: {
    fr: 'Dimanche - Jeudi : 8h00 - 17h00',
    ar: 'الأحد - الخميس: 8:00 - 17:00',
  },
  city: { fr: 'Oran', ar: 'وهران' },
  wilaya: { fr: 'Oran', ar: 'ولاية وهران' },
  social: {
    facebook: 'https://facebook.com/groupedentalimport',
    instagram: 'https://instagram.com/groupedentalimport',
    linkedin: 'https://linkedin.com/company/groupedentalimport',
    youtube: 'https://youtube.com/@groupedentalimport',
  },
};

// ============================================================
// COMPANY INFO
// ============================================================
export const companyInfo = {
  name: { fr: 'OUADAH DENTAL GROUPE (ODG)', ar: 'مجموعة وقاح لطب الأسنان (ODG)' },
  slogan: {
    fr: 'L\'excellence au service de votre pratique',
    ar: 'التميز في خدمة ممارستكم',
  },
  foundedYear: 2009,
  stats: {
    years: 16,
    products: 200,
    clients: 2500,
    cities: 48,
    satisfaction: 98,
    warranty: 5,
    brands: 15,
    installations: 3500,
  },
};

// ============================================================
// HELPER FUNCTIONS
// ============================================================
export function getProductBySlug(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

export function getProductsByCategory(categorySlug: string): Product[] {
  return products.filter((p) => p.category === categorySlug);
}

export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find((c) => c.slug === slug);
}

export function getFeaturedProducts(): Product[] {
  return products.filter((p) => p.isFeatured);
}

export function getNewProducts(): Product[] {
  return products.filter((p) => p.isNew);
}

export function getBestSellerProducts(): Product[] {
  return products.filter((p) => p.isBestSeller);
}

export function getBlogPostBySlug(slug: string): BlogPost | undefined {
  return blogPosts.find((p) => p.slug === slug);
}

export function getRelatedProducts(productId: string, limit: number = 3): Product[] {
  const product = products.find((p) => p.id === productId);
  if (!product) return [];
  return products
    .filter((p) => p.id !== productId && p.category === product.category)
    .slice(0, limit);
}

export function formatPrice(price: number, lang: 'fr' | 'ar' = 'fr'): string {
  const formatted = new Intl.NumberFormat(lang === 'ar' ? 'ar-DZ' : 'fr-DZ').format(price);
  const currency = lang === 'ar' ? 'د.ج' : 'DA';
  return `${formatted} ${currency}`;
}
