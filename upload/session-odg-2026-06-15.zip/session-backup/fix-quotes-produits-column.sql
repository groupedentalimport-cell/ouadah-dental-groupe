-- ============================================
-- EURL ODG / OUADAH DENTAL GROUPE
-- Fix: Ensure produits_selectionnes column is jsonb type
-- This fixes the "invalid input syntax for type uuid" error
-- when submitting quotes with product details.
-- Execute this in Supabase SQL Editor
-- ============================================

-- Step 1: Check current column type and fix it
-- If produits_selectionnes is uuid[] or text, convert it to jsonb

-- First, drop the column and recreate it as jsonb
-- (This will lose existing product selection data in quotes,
--  but quote product data can be re-associated via the product IDs)

-- Option A: If you want to preserve existing data, run this first:
-- CREATE TEMP TABLE quotes_backup AS SELECT * FROM quotes;

-- Alter the column type to jsonb
ALTER TABLE quotes
ALTER COLUMN produits_selectionnes TYPE jsonb
USING produits_selectionnes::text::jsonb;

-- If the above fails (e.g., column is uuid[]), use this instead:
-- ALTER TABLE quotes DROP COLUMN produits_selectionnes;
-- ALTER TABLE quotes ADD COLUMN produits_selectionnes jsonb DEFAULT '[]'::jsonb;

-- Step 2: Verify the column type
SELECT column_name, data_type, udt_name
FROM information_schema.columns
WHERE table_name = 'quotes' AND column_name = 'produits_selectionnes';
