'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Search,
  Check,
  CheckCircle2,
  ArrowLeft,
  ArrowRight,
  User,
  Package,
  ClipboardCheck,
  Pencil,
  X,
  Loader2,
} from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { useData } from '@/lib/data-service';
import { useQuoteCart } from '@/hooks/useQuoteCart';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
  DialogHeader,
} from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';

// ============================================================
// WILAYAS LIST
// ============================================================
const wilayas = [
  'Adrar', 'Chlef', 'Laghouat', 'Oum El Bouaghi', 'Batna', 'Béjaïa', 'Biskra',
  'Béchar', 'Blida', 'Bouira', 'Tamanrasset', 'Tébessa', 'Tlemcen', 'Tiaret',
  'Tizi Ouzou', 'Alger', 'Djelfa', 'Jijel', 'Sétif', 'Saïda', 'Skikda',
  'Sidi Bel Abbès', 'Annaba', 'Guelma', 'Constantine', 'Médéa', 'Mostaganem',
  'M\'Sila', 'Mascara', 'Ouargla', 'Oran', 'El Bayadh', 'Illizi', 'Bordj Bou Arréridj',
  'Boumerdès', 'El Tarf', 'Tindouf', 'Tissemsilt', 'El Oued', 'Khenchela',
  'Souk Ahras', 'Tipaza', 'Mila', 'Aïn Defla', 'Naâma', 'Aïn Témouchent',
  'Ghardaïa', 'Relizane', 'El M\'Ghair', 'El Meniaa', 'Ouled Djellal',
  'Bordj Badji Mokhtar', 'Béni Abbès', 'Timimoun', 'Touggourt',
  'Djanet', 'In Salah', 'In Guezzam',
];

// ============================================================
// SCHEMAS
// ============================================================
const step1Schema = z.object({
  fullName: z.string().min(2, { message: 'Min 2 characters' }),
  email: z.email({ message: 'Invalid email' }),
  phone: z.string().regex(/^(05|06|07)\d{8}$/, { message: 'Format: 05/06/07 + 8 digits' }),
  wilaya: z.string().min(1, { message: 'Required' }),
  clientType: z.enum(['Dentiste', 'Clinique', 'Revendeur', 'Comptoir'], { message: 'Required' }),
});

type Step1Data = z.infer<typeof step1Schema>;

// ============================================================
// STEP DEFINITIONS
// ============================================================
const steps = [
  { key: 'info', icon: User, labelFr: 'Vos informations', labelAr: 'معلوماتك' },
  { key: 'products', icon: Package, labelFr: 'Produits souhaités', labelAr: 'المنتجات المطلوبة' },
  { key: 'confirm', icon: ClipboardCheck, labelFr: 'Confirmation', labelAr: 'التأكيد' },
];

export default function QuoteWizard() {
  const { language, t, isRTL } = useTranslation();
  const { navigate } = useRouter();
  const { products, categories, formatPrice } = useData();
  const {
    items,
    incrementQuantity,
    decrementQuantity,
    removeItem,
    addItem,
    clearCart,
  } = useQuoteCart();

  const [currentStep, setCurrentStep] = useState(0);
  const [notes, setNotes] = useState('');
  const [addProductDialogOpen, setAddProductDialogOpen] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [submitted, setSubmitted] = useState(false);

  // Step 1 form
  const form = useForm<Step1Data>({
    resolver: zodResolver(step1Schema),
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      wilaya: '',
      clientType: '' as unknown as Step1Data['clientType'],
    },
    mode: 'onChange',
  });

  const { register, handleSubmit, formState: { errors }, watch, setValue, trigger } = form;
  const formValues = watch();

  const getStepLabel = (stepIdx: number) => {
    const step = steps[stepIdx];
    return isRTL ? step.labelAr : step.labelFr;
  };

  // Filter products for the "add product" dialog
  const filteredDialogProducts = products.filter((p) => {
    if (!productSearch) return true;
    const q = productSearch.toLowerCase();
    return (
      p.name[language].toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.ref.toLowerCase().includes(q)
    );
  });

  const getCategoryName = (slug: string) => {
    const cat = categories.find((c) => c.slug === slug);
    return cat ? cat.name[language] : slug;
  };

  // Navigation handlers
  const goToStep = (step: number) => {
    if (step < 0 || step > 2) return;
    if (step > currentStep) {
      // Validate before advancing
      if (currentStep === 0) {
        trigger().then((valid) => {
          if (valid) setCurrentStep(step);
        });
      } else {
        setCurrentStep(step);
      }
    } else {
      setCurrentStep(step);
    }
  };

  const handleNext = () => {
    if (currentStep === 0) {
      trigger().then((valid) => {
        if (valid) setCurrentStep(1);
      });
    } else if (currentStep === 1) {
      setCurrentStep(2);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) setCurrentStep(currentStep - 1);
  };

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitQuote = async () => {
    setIsSubmitting(true);
    try {
      const step1Data = form.getValues();
      // Map cart items to a JSONB-compatible format for Supabase
      // The produits_selectionnes column expects jsonb (array of objects)
      // We store product details as simple objects with string values (no nested objects)
      // because Supabase jsonb columns handle flat objects better than nested ones
      const cartItems = items.map((item) => ({
        id: item.id,
        slug: item.slug,
        name: typeof item.name === 'object'
          ? (item.name.fr || item.name.ar || item.slug)
          : String(item.name),
        quantity: item.quantity,
      }));

      const quoteData = {
        nom: step1Data.fullName,
        email: step1Data.email,
        telephone: step1Data.phone,
        wilaya: step1Data.wilaya,
        type_client: step1Data.clientType?.toLowerCase() || 'dentiste',
        produits_selectionnes: cartItems,
        message: notes || null,
        statut: 'nouveau',
      };

      if (isSupabaseConfigured()) {
        let { error } = await supabase.from('quotes').insert([quoteData]);

        // If the first attempt fails (e.g., produits_selectionnes column type mismatch),
        // retry with just product IDs (UUID array) as fallback
        if (error && error.message?.includes('uuid')) {
          console.warn('Retrying quote insert with UUID array fallback...');
          const fallbackData = {
            ...quoteData,
            produits_selectionnes: items.map((item) => item.id),
          };
          const fallbackResult = await supabase.from('quotes').insert([fallbackData]);
          error = fallbackResult.error;
        }

        if (error) {
          console.error('Error submitting quote:', error);
          throw new Error(error.message);
        }
      } else {
        console.warn('Supabase not configured — quote not saved to database');
      }

      setSubmitted(true);
      clearCart();
      toast.success(t('quote.success'));
    } catch (err) {
      console.error('Error submitting quote:', err);
      toast.error(
        language === 'ar'
          ? 'حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.'
          : 'Erreur lors de l\'envoi du devis. Veuillez réessayer.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // ============================================================
  // RENDER: PROGRESS BAR
  // ============================================================
  const ProgressBar = () => (
    <div className="mb-8 md:mb-10">
      <div className="flex items-center justify-between relative">
        {/* Connecting Lines */}
        <div className="absolute top-5 start-0 end-0 h-0.5 bg-neutral-200 z-0" />
        <div
          className="absolute top-5 start-0 h-0.5 z-10 transition-all duration-500"
          style={{
            width: currentStep > 0 ? `${(currentStep / 2) * 100}%` : '0%',
            backgroundColor: 'var(--dental-primary)',
          }}
        />

        {steps.map((step, idx) => {
          const Icon = step.icon;
          const isCompleted = idx < currentStep;
          const isCurrent = idx === currentStep;

          return (
            <div key={idx} className="flex flex-col items-center z-20 relative">
              <button
                onClick={() => {
                  if (idx < currentStep) setCurrentStep(idx);
                }}
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300',
                  isCompleted && 'border-primary-500 text-white',
                  isCurrent && 'border-primary-500 ring-4 ring-primary-100 text-primary-500',
                  !isCompleted && !isCurrent && 'border-neutral-300 text-neutral-400 bg-white'
                )}
                style={{
                  backgroundColor: isCompleted ? 'var(--dental-primary)' : isCurrent ? '#fff' : '#fff',
                }}
              >
                {isCompleted ? (
                  <Check className="h-5 w-5" />
                ) : (
                  <Icon className="h-5 w-5" />
                )}
              </button>
              <span
                className={cn(
                  'mt-2 text-xs font-medium text-center max-w-[80px]',
                  isCurrent ? 'text-primary-600' : isCompleted ? 'text-foreground' : 'text-muted-foreground'
                )}
              >
                {getStepLabel(idx)}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );

  // ============================================================
  // SUCCESS STATE
  // ============================================================
  if (submitted) {
    return (
      <div
        className="w-full py-16 md:py-24"
        style={{ backgroundColor: '#F8FAFC' }}
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <div className="mx-auto max-w-lg px-4 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 15 }}
          >
            <CheckCircle2
              className="h-20 w-20 mx-auto mb-6"
              style={{ color: 'var(--dental-success)' }}
            />
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-2xl md:text-3xl font-bold text-foreground mb-3"
            style={{
              fontFamily: isRTL
                ? "var(--font-cairo), 'Cairo', sans-serif"
                : "var(--font-syne), 'Syne', sans-serif",
            }}
          >
            {t('quote.success')}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-muted-foreground mb-8"
          >
            {t('quote.successDesc')}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <Button
              onClick={() => navigate('/catalogue')}
              size="lg"
              className="gap-2 rounded-lg text-white"
              style={{ backgroundColor: 'var(--dental-primary)' }}
            >
              <ShoppingCart className="h-4 w-4" />
              {t('quote.browseCatalogue')}
            </Button>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="w-full py-8 md:py-12"
      style={{ backgroundColor: '#F8FAFC' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div className="mx-auto max-w-3xl px-4 md:px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <h1
            className="text-2xl md:text-3xl font-bold text-foreground mb-2"
            style={{
              fontFamily: isRTL
                ? "var(--font-cairo), 'Cairo', sans-serif"
                : "var(--font-syne), 'Syne', sans-serif",
            }}
          >
            {t('quote.title')}
          </h1>
          <p className="text-muted-foreground text-sm md:text-base">
            {t('quote.subtitle')}
          </p>
        </motion.div>

        {/* Progress Bar */}
        <ProgressBar />

        {/* Step Content */}
        <AnimatePresence mode="wait">
          {/* ========== STEP 1: Vos Informations ========== */}
          {currentStep === 0 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: isRTL ? -30 : 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: isRTL ? 30 : -30 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="p-5 md:p-8">
                <h2
                  className="text-lg font-semibold text-foreground mb-6"
                  style={{
                    fontFamily: isRTL
                      ? "var(--font-cairo), 'Cairo', sans-serif"
                      : "var(--font-syne), 'Syne', sans-serif",
                  }}
                >
                  {getStepLabel(0)}
                </h2>

                <form className="flex flex-col gap-5" onSubmit={(e) => e.preventDefault()}>
                  {/* Full Name */}
                  <div className="grid gap-2">
                    <Label htmlFor="fullName">{t('quote.name')} *</Label>
                    <Input
                      id="fullName"
                      {...register('fullName')}
                      placeholder={t('quote.name')}
                      className={cn(errors.fullName && 'border-destructive')}
                    />
                    {errors.fullName && (
                      <p className="text-xs text-destructive">{errors.fullName.message}</p>
                    )}
                  </div>

                  {/* Email */}
                  <div className="grid gap-2">
                    <Label htmlFor="email">{t('quote.email')} *</Label>
                    <Input
                      id="email"
                      type="email"
                      {...register('email')}
                      placeholder="email@example.com"
                      className={cn(errors.email && 'border-destructive')}
                    />
                    {errors.email && (
                      <p className="text-xs text-destructive">{errors.email.message}</p>
                    )}
                  </div>

                  {/* Phone */}
                  <div className="grid gap-2">
                    <Label htmlFor="phone">{t('quote.phone')} *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      {...register('phone')}
                      placeholder="05XXXXXXXX"
                      className={cn(errors.phone && 'border-destructive')}
                    />
                    {errors.phone && (
                      <p className="text-xs text-destructive">{errors.phone.message}</p>
                    )}
                  </div>

                  {/* Wilaya */}
                  <div className="grid gap-2">
                    <Label>{t('quote.wilaya')} *</Label>
                    <Select
                      value={formValues.wilaya}
                      onValueChange={(val) => setValue('wilaya', val, { shouldValidate: true })}
                    >
                      <SelectTrigger className={cn(errors.wilaya && 'border-destructive')}>
                        <SelectValue placeholder={t('quote.wilaya')} />
                      </SelectTrigger>
                      <SelectContent className="max-h-60">
                        {wilayas.map((w) => (
                          <SelectItem key={w} value={w}>
                            {w}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.wilaya && (
                      <p className="text-xs text-destructive">{errors.wilaya.message}</p>
                    )}
                  </div>

                  {/* Client Type */}
                  <div className="grid gap-2">
                    <Label>
                      {isRTL ? 'نوع العميل' : 'Type de client'} *
                    </Label>
                    <RadioGroup
                      value={formValues.clientType || ''}
                      onValueChange={(val) =>
                        setValue('clientType', val as Step1Data['clientType'], { shouldValidate: true })
                      }
                      className="grid grid-cols-2 gap-3"
                    >
                      {['Dentiste', 'Clinique', 'Revendeur', 'Comptoir'].map((type) => (
                        <div key={type} className="flex items-center gap-2">
                          <RadioGroupItem value={type} id={`type-${type}`} />
                          <Label htmlFor={`type-${type}`} className="cursor-pointer text-sm">
                            {type === 'Dentiste'
                              ? isRTL ? 'طبيب أسنان' : 'Dentiste'
                              : type === 'Clinique'
                                ? isRTL ? 'عيادة' : 'Clinique'
                                : type === 'Revendeur'
                                  ? isRTL ? 'موزع' : 'Revendeur'
                                  : isRTL ? 'كونتوار' : 'Comptoir'}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                    {errors.clientType && (
                      <p className="text-xs text-destructive">{errors.clientType.message}</p>
                    )}
                  </div>
                </form>

                {/* Navigation */}
                <div className={cn('flex justify-end mt-8', isRTL && 'flex-row-reverse')}>
                  <Button
                    onClick={handleNext}
                    size="lg"
                    className="gap-2 rounded-lg text-white min-w-[140px]"
                    style={{ backgroundColor: 'var(--dental-primary)' }}
                  >
                    {t('quote.next')}
                    {isRTL ? <ArrowLeft className="h-4 w-4" /> : <ArrowRight className="h-4 w-4" />}
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}

          {/* ========== STEP 2: Produits souhaités ========== */}
          {currentStep === 1 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: isRTL ? -30 : 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: isRTL ? 30 : -30 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="p-5 md:p-8">
                <div className="flex items-center justify-between mb-6">
                  <h2
                    className="text-lg font-semibold text-foreground"
                    style={{
                      fontFamily: isRTL
                        ? "var(--font-cairo), 'Cairo', sans-serif"
                        : "var(--font-syne), 'Syne', sans-serif",
                    }}
                  >
                    {getStepLabel(1)}
                  </h2>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setProductSearch('');
                      setAddProductDialogOpen(true);
                    }}
                    className="gap-1.5"
                  >
                    <Plus className="h-4 w-4" />
                    {t('quote.addItem')}
                  </Button>
                </div>

                {/* Product List */}
                {items.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <ShoppingCart
                      className="h-12 w-12 text-muted-foreground mb-4"
                    />
                    <p className="text-muted-foreground font-medium mb-1">
                      {t('quote.empty')}
                    </p>
                    <p className="text-sm text-muted-foreground mb-4">
                      {t('quote.emptyDesc')}
                    </p>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setProductSearch('');
                        setAddProductDialogOpen(true);
                      }}
                      className="gap-2"
                    >
                      <Plus className="h-4 w-4" />
                      {t('quote.addItem')}
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    {items.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-4 p-3 rounded-lg border border-neutral-100 bg-white"
                      >
                        <img
                          src={item.image}
                          alt={item.name[language]}
                          className="w-16 h-12 object-cover rounded-md shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground text-sm truncate">
                            {item.name[language]}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {item.ref} &middot; {formatPrice(item.price, language)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => decrementQuantity(item.id)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center text-sm font-medium">
                            {item.quantity}
                          </span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => incrementQuantity(item.id)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => removeItem(item.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Notes */}
                <div className="mt-6">
                  <Label className="mb-2 block">{t('quote.notes')}</Label>
                  <Textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder={t('quote.notesPlaceholder')}
                    rows={4}
                  />
                </div>

                {/* Navigation */}
                <div className={cn('flex justify-between mt-8', isRTL && 'flex-row-reverse')}>
                  <Button
                    variant="outline"
                    onClick={handlePrev}
                    size="lg"
                    className="gap-2 rounded-lg min-w-[140px]"
                  >
                    {isRTL ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
                    {t('quote.previous')}
                  </Button>
                  <Button
                    onClick={handleNext}
                    size="lg"
                    className="gap-2 rounded-lg text-white min-w-[140px]"
                    style={{ backgroundColor: 'var(--dental-primary)' }}
                  >
                    {t('quote.next')}
                    {isRTL ? <ArrowLeft className="h-4 w-4" /> : <ArrowRight className="h-4 w-4" />}
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}

          {/* ========== STEP 3: Confirmation ========== */}
          {currentStep === 2 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: isRTL ? -30 : 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: isRTL ? 30 : -30 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="p-5 md:p-8">
                <h2
                  className="text-lg font-semibold text-foreground mb-6"
                  style={{
                    fontFamily: isRTL
                      ? "var(--font-cairo), 'Cairo', sans-serif"
                      : "var(--font-syne), 'Syne', sans-serif",
                  }}
                >
                  {getStepLabel(2)}
                </h2>

                {/* Client Info Summary */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-semibold text-foreground">
                      {getStepLabel(0)}
                    </h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setCurrentStep(0)}
                      className="gap-1 text-primary-600"
                    >
                      <Pencil className="h-3 w-3" />
                      {t('common.edit')}
                    </Button>
                  </div>
                  <div className="bg-muted/50 rounded-lg p-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-muted-foreground">{t('quote.name')}:</span>{' '}
                      <span className="font-medium text-foreground">{formValues.fullName}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">{t('quote.email')}:</span>{' '}
                      <span className="font-medium text-foreground">{formValues.email}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">{t('quote.phone')}:</span>{' '}
                      <span className="font-medium text-foreground">{formValues.phone}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">{t('quote.wilaya')}:</span>{' '}
                      <span className="font-medium text-foreground">{formValues.wilaya}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">
                        {isRTL ? 'نوع العميل' : 'Type de client'}:
                      </span>{' '}
                      <span className="font-medium text-foreground">
                        {formValues.clientType === 'Dentiste'
                          ? isRTL ? 'طبيب أسنان' : 'Dentiste'
                          : formValues.clientType === 'Clinique'
                            ? isRTL ? 'عيادة' : 'Clinique'
                            : formValues.clientType === 'Revendeur'
                              ? isRTL ? 'موزع' : 'Revendeur'
                              : formValues.clientType === 'Comptoir'
                                ? isRTL ? 'كونتوار' : 'Comptoir'
                                : formValues.clientType}
                      </span>
                    </div>
                  </div>
                </div>

                <Separator className="my-4" />

                {/* Products Summary */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-semibold text-foreground">
                      {t('quote.products')}
                    </h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setCurrentStep(1)}
                      className="gap-1 text-primary-600"
                    >
                      <Pencil className="h-3 w-3" />
                      {t('common.edit')}
                    </Button>
                  </div>
                  {items.length === 0 ? (
                    <p className="text-sm text-muted-foreground italic">
                      {t('quote.empty')}
                    </p>
                  ) : (
                    <div className="bg-muted/50 rounded-lg p-4 flex flex-col gap-3">
                      {items.map((item) => (
                        <div
                          key={item.id}
                          className="flex items-center gap-3 text-sm"
                        >
                          <img
                            src={item.image}
                            alt=""
                            className="w-10 h-8 object-cover rounded shrink-0"
                          />
                          <span className="flex-1 font-medium text-foreground truncate">
                            {item.name[language]}
                          </span>
                          <span className="text-muted-foreground">
                            x{item.quantity}
                          </span>
                          <span className="font-medium text-foreground">
                            {formatPrice(item.price * item.quantity, language)}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Notes Summary */}
                {notes && (
                  <>
                    <Separator className="my-4" />
                    <div className="mb-6">
                      <h3 className="text-sm font-semibold text-foreground mb-2">
                        {t('quote.notes')}
                      </h3>
                      <div className="bg-muted/50 rounded-lg p-4 text-sm text-foreground">
                        {notes}
                      </div>
                    </div>
                  </>
                )}

                {/* Navigation */}
                <div className={cn('flex justify-between mt-8', isRTL && 'flex-row-reverse')}>
                  <Button
                    variant="outline"
                    onClick={handlePrev}
                    size="lg"
                    className="gap-2 rounded-lg min-w-[140px]"
                  >
                    {isRTL ? <ArrowRight className="h-4 w-4" /> : <ArrowLeft className="h-4 w-4" />}
                    {t('quote.previous')}
                  </Button>
                  <Button
                    onClick={handleSubmitQuote}
                    disabled={isSubmitting}
                    size="lg"
                    className="gap-2 rounded-lg text-white min-w-[180px]"
                    style={{ backgroundColor: 'var(--dental-primary)' }}
                  >
                    {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                    {t('quote.submit')}
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Add Product Dialog */}
      <Dialog open={addProductDialogOpen} onOpenChange={setAddProductDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              {t('quote.addItem')}
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setAddProductDialogOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </DialogTitle>
            <DialogDescription className="sr-only">
              {t('quote.addItem')}
            </DialogDescription>
          </DialogHeader>

          {/* Search */}
          <div className="relative mb-4">
            <Search
              className={cn(
                'absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground',
                isRTL ? 'right-3' : 'left-3'
              )}
            />
            <Input
              value={productSearch}
              onChange={(e) => setProductSearch(e.target.value)}
              placeholder={t('catalogue.search')}
              className={cn(isRTL ? 'pr-9 pl-3' : 'pl-9 pr-3')}
            />
          </div>

          {/* Product Grid */}
          <div className="flex-1 overflow-y-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredDialogProducts.map((p) => {
                const inCart = items.some((i) => i.id === p.id);
                return (
                  <div
                    key={p.id}
                    className="flex items-center gap-3 p-3 rounded-lg border border-neutral-100 hover:border-primary-200 transition-colors"
                  >
                    <img
                      src={p.images[0]}
                      alt={p.name[language]}
                      className="w-14 h-11 object-cover rounded shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {p.name[language]}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatPrice(p.price, language)}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant={inCart ? 'secondary' : 'default'}
                      onClick={() => {
                        if (!inCart) {
                          addItem({
                            id: p.id,
                            slug: p.slug,
                            name: p.name,
                            price: p.price,
                            image: p.images[0],
                            category: p.category,
                            ref: p.ref,
                          });
                          toast.success(t('products.addToQuote'), {
                            description: p.name[language],
                          });
                        }
                      }}
                      disabled={inCart}
                      className="gap-1 text-xs shrink-0"
                      style={!inCart ? { backgroundColor: 'var(--dental-primary)', color: '#fff' } : {}}
                    >
                      {inCart ? <Check className="h-3 w-3" /> : <Plus className="h-3 w-3" />}
                      {inCart ? (isRTL ? 'مضاف' : 'Ajouté') : (isRTL ? 'إضافة' : 'Ajouter')}
                    </Button>
                  </div>
                );
              })}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
