'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Package,
  FileText,
  Mail,
  Newspaper,
  Menu,
  LogOut,
  X,
  FolderOpen,
  Settings,
} from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { useAdminAuth } from '@/lib/admin-auth';
import { useSiteSettings } from '@/lib/site-settings';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';

interface AdminLayoutProps {
  children: React.ReactNode;
  activeRoute: string;
}

const navItems = [
  { key: 'admin-dashboard', icon: LayoutDashboard, labelKey: 'nav.dashboard', path: '/admin/dashboard' },
  { key: 'admin-products', icon: Package, labelKey: 'nav.products', path: '/admin/products' },
  { key: 'admin-products-new', icon: Package, labelKey: 'nav.products', path: '/admin/products' },
  { key: 'admin-products-edit', icon: Package, labelKey: 'nav.products', path: '/admin/products' },
  { key: 'admin-blog', icon: Newspaper, labelKey: 'nav.blogPosts', path: '/admin/blog' },
  { key: 'admin-blog-new', icon: Newspaper, labelKey: 'nav.blogPosts', path: '/admin/blog' },
  { key: 'admin-quotes', icon: FileText, labelKey: 'nav.quotes', path: '/admin/quotes' },
  { key: 'admin-messages', icon: Mail, labelKey: 'nav.messages', path: '/admin/messages' },
  { key: 'admin-categories', icon: FolderOpen, labelKey: 'nav.categories', path: '/admin/categories' },
  { key: 'admin-settings', icon: Settings, labelKey: 'nav.settings', path: '/admin/settings' },
];

const sidebarLinks = [
  { icon: LayoutDashboard, labelKey: 'nav.dashboard', path: '/admin/dashboard', route: 'admin-dashboard' },
  { icon: Package, labelKey: 'nav.products', path: '/admin/products', route: 'admin-products' },
  { icon: Newspaper, labelKey: 'nav.blogPosts', path: '/admin/blog', route: 'admin-blog' },
  { icon: FileText, labelKey: 'nav.quotes', path: '/admin/quotes', route: 'admin-quotes' },
  { icon: Mail, labelKey: 'nav.messages', path: '/admin/messages', route: 'admin-messages' },
  { icon: FolderOpen, labelKey: 'nav.categories', path: '/admin/categories', route: 'admin-categories' },
  { icon: Settings, labelKey: 'nav.settings', path: '/admin/settings', route: 'admin-settings' },
];

function SidebarContent({
  activeRoute,
  onNavigate,
  onLogout,
}: {
  activeRoute: string;
  onNavigate: (path: string) => void;
  onLogout: () => void;
}) {
  const { t, isRTL } = useTranslation();
  const { getText } = useSiteSettings();

  // Dynamic logo settings — fallback to local logo files if not configured in admin
  const logoIconUrl = getText('logo.icon_url') || '/logo-odg.jpg';
  const logoFullUrl = getText('logo.full_url') || '/logo-odg-full.png';
  const brandText = getText('logo.brand_text') || 'ODG';

  // Determine the active sidebar item
  const activeItem = navItems.find((n) => n.key === activeRoute);
  const activeLink = activeItem
    ? sidebarLinks.find((s) => s.path === activeItem.path)
    : null;
  const activePath = activeLink?.path || '/admin/dashboard';

  return (
    <div
      className="flex flex-col h-full"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Logo */}
      <div className="p-6 pb-4">
        <div className="flex items-center gap-3">
          {logoFullUrl ? (
            <img
              src={logoFullUrl}
              alt={brandText}
              className="h-10"
              style={{ objectFit: 'contain' }}
              onError={(e) => {
                const img = e.target as HTMLImageElement;
                img.style.display = 'none';
                const fallback = img.parentElement?.querySelector('.admin-logo-fallback') as HTMLElement;
                if (fallback) fallback.style.display = 'flex';
              }}
            />
          ) : null}
          <div className="admin-logo-fallback flex items-center gap-3" style={{ display: logoFullUrl ? 'none' : 'flex' }}>
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center overflow-hidden"
              style={{ backgroundColor: 'var(--dental-primary)' }}
            >
              {logoIconUrl ? (
                <img
                  src={logoIconUrl}
                  alt="Logo"
                  className="w-full h-full object-contain p-1"
                  style={{ filter: 'brightness(0) invert(1)' }}
                  onError={(e) => {
                    const img = e.target as HTMLImageElement;
                    img.style.display = 'none';
                    const fallback = img.parentElement?.querySelector('.icon-text-fallback') as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
              ) : null}
              <span className="icon-text-fallback text-white font-bold text-sm" style={{ display: logoIconUrl ? 'none' : 'inline' }}>
                {brandText.slice(0, 2).toUpperCase()}
              </span>
            </div>
            <div>
              <h2 className="font-bold text-foreground text-base">{brandText}</h2>
              <p className="text-xs text-neutral-500">{t('admin.title')}</p>
            </div>
          </div>
        </div>
      </div>

      <Separator />

      {/* Nav Links */}
      <nav className="flex-1 p-4 space-y-1">
        {sidebarLinks.map((link) => {
          const isActive = activePath === link.path;
          return (
            <button
              key={link.path}
              onClick={() => onNavigate(link.path)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isRTL ? 'flex-row-reverse text-right' : 'text-left'
              } ${
                isActive
                  ? 'text-white'
                  : 'text-neutral-600 hover:bg-neutral-100 hover:text-foreground'
              }`}
              style={
                isActive
                  ? { backgroundColor: 'var(--dental-primary)' }
                  : undefined
              }
            >
              <link.icon className="h-5 w-5 shrink-0" />
              <span>{t(link.labelKey)}</span>
            </button>
          );
        })}
      </nav>

      <Separator />

      {/* Logout */}
      <div className="p-4">
        <button
          onClick={onLogout}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 transition-colors ${
            isRTL ? 'flex-row-reverse text-right' : 'text-left'
          }`}
        >
          <LogOut className="h-5 w-5 shrink-0" />
          <span>{t('nav.logout')}</span>
        </button>
      </div>
    </div>
  );
}

export default function AdminLayout({ children, activeRoute }: AdminLayoutProps) {
  const { t, isRTL } = useTranslation();
  const { navigate } = useRouter();
  const { logout, userEmail } = useAdminAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNavigate = (path: string) => {
    navigate(path);
    setMobileOpen(false);
  };

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
    setMobileOpen(false);
  };

  // Determine page title
  const activeItem = navItems.find((n) => n.key === activeRoute);
  const activeLink = activeItem
    ? sidebarLinks.find((s) => s.path === activeItem.path)
    : null;
  const pageTitle = activeLink ? t(activeLink.labelKey) : t('nav.dashboard');

  // Get user initials for avatar
  const userInitial = userEmail ? userEmail.charAt(0).toUpperCase() : 'A';
  const displayName = userEmail ? userEmail.split('@')[0] : 'Admin';

  return (
    <div className="min-h-screen flex" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-white border-e border-neutral-200 z-30">
        <SidebarContent
          activeRoute={activeRoute}
          onNavigate={handleNavigate}
          onLogout={handleLogout}
        />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent
          side={isRTL ? 'right' : 'left'}
          className="p-0 w-64"
        >
          <SheetHeader className="sr-only">
            <SheetTitle>{t('admin.title')}</SheetTitle>
            <SheetDescription>Navigation menu</SheetDescription>
          </SheetHeader>
          <SidebarContent
            activeRoute={activeRoute}
            onNavigate={handleNavigate}
            onLogout={handleLogout}
          />
        </SheetContent>
      </Sheet>

      {/* Main Area */}
      <div className={`flex-1 ${isRTL ? 'lg:me-64' : 'lg:ms-64'}`}>
        {/* Top Bar */}
        <header className="sticky top-0 z-20 bg-white border-b border-neutral-200 px-4 md:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setMobileOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-bold text-foreground">{pageTitle}</h1>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 text-sm text-neutral-600">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold"
                style={{ backgroundColor: 'var(--dental-primary)' }}
              >
                {userInitial}
              </div>
              <span>{displayName}</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <LogOut className="h-4 w-4 me-1" />
              <span className="hidden sm:inline">{t('nav.logout')}</span>
            </Button>
          </div>
        </header>

        {/* Content */}
        <main className="p-4 md:p-6 bg-neutral-50 min-h-[calc(100vh-4rem)]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeRoute}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
