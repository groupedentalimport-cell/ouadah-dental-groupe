'use client';

import { motion } from 'framer-motion';
import {
  Stethoscope,
  Facebook,
  Instagram,
  Linkedin,
  MapPin,
  Phone,
  Mail,
  Clock,
} from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { useData } from '@/lib/data-service';
import { useSiteSettings } from '@/lib/site-settings';

interface FooterLink {
  label: string;
  route: string;
}

export default function Footer() {
  const { language, t, isRTL } = useTranslation();
  const { navigate } = useRouter();
  const { contactInfo } = useData();
  const { getText } = useSiteSettings();

  // Dynamic logo settings — fallback to local logo files if not configured in admin
  const logoIconUrl = getText('logo.icon_url') || '/logo-odg.jpg';
  const logoFullUrl = getText('logo.full_url') || '/logo-odg-full.png';
  const brandText = getText('logo.brand_text') || t('nav.brand');

  const quickLinks: FooterLink[] = [
    { label: t('nav.catalogue'), route: '/catalogue' },
    { label: t('nav.blog'), route: '/blog' },
    { label: t('nav.about'), route: '/about' },
    { label: t('nav.contact'), route: '/contact' },
    { label: t('nav.quote'), route: '/devis' },
  ];

  const legalLinks: FooterLink[] = [
    { label: t('footer.legal.mentions'), route: '/mentions-legales' },
    { label: t('footer.privacy'), route: '/politique-confidentialite' },
    { label: t('footer.legal.cgv'), route: '/conditions-vente' },
  ];

  const socialLinks = [
    { icon: Facebook, href: contactInfo.social.facebook, label: 'Facebook' },
    { icon: Instagram, href: contactInfo.social.instagram, label: 'Instagram' },
    { icon: Linkedin, href: contactInfo.social.linkedin, label: 'LinkedIn' },
  ];

  const footerVariants = {
    hidden: { opacity: 0, y: 40 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  };

  const columnVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 + i * 0.1,
        duration: 0.5,
        ease: 'easeOut',
      },
    }),
  };

  return (
    <motion.footer
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '-50px' }}
      variants={footerVariants}
      className="w-full"
      style={{ backgroundColor: '#1E3A5F' }}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* Main Footer Content */}
      <div className="mx-auto max-w-7xl px-4 md:px-6 py-8 md:py-12">
        <div
          className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 ${
            isRTL ? 'direction-rtl' : ''
          }`}
        >
          {/* Column 1: Brand */}
          <motion.div
            custom={0}
            variants={columnVariants}
            className="sm:col-span-2 lg:col-span-1"
          >
            {/* Logo */}
            <div
              className={`flex items-center gap-2 mb-4 ${
                isRTL ? 'flex-row-reverse' : ''
              }`}
            >
              {logoFullUrl ? (
                <img
                  src={logoFullUrl}
                  alt={brandText}
                  className="h-8"
                  style={{ objectFit: 'contain', filter: 'brightness(0) invert(1)' }}
                  onError={(e) => {
                    const img = e.target as HTMLImageElement;
                    img.style.display = 'none';
                    const fallback = img.parentElement?.querySelector('.footer-logo-fallback') as HTMLElement;
                    if (fallback) fallback.style.display = 'flex';
                  }}
                />
              ) : null}
              <div className="footer-logo-fallback flex items-center gap-2" style={{ display: logoFullUrl ? 'none' : 'flex' }}>
                {logoIconUrl ? (
                  <img
                    src={logoIconUrl}
                    alt="Logo"
                    className="h-7 w-7"
                    style={{ objectFit: 'contain', filter: 'brightness(0) invert(1)' }}
                    onError={(e) => {
                      const img = e.target as HTMLImageElement;
                      img.style.display = 'none';
                    }}
                  />
                ) : (
                  <Stethoscope className="h-7 w-7 text-white" />
                )}
                <span
                  className="text-xl font-display font-bold text-white"
                  style={{
                    fontFamily: "var(--font-syne), 'Syne', sans-serif",
                  }}
                >
                  {brandText}
                </span>
              </div>
            </div>

            {/* Description */}
            <p className="text-neutral-300 text-sm leading-relaxed mb-6 max-w-xs">
              {t('footer.description')}
            </p>

            {/* Social Icons */}
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="flex items-center justify-center h-9 w-9 rounded-lg bg-white/10 text-neutral-400 hover:bg-accent hover:text-white transition-colors duration-200"
                >
                  <social.icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </motion.div>

          {/* Column 2: Quick Links */}
          <motion.div custom={1} variants={columnVariants}>
            <h3 className="text-white font-display font-semibold text-sm uppercase tracking-wider mb-4">
              {t('footer.quickLinks')}
            </h3>
            <ul className="space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.route}>
                  <button
                    onClick={() => navigate(link.route)}
                    className="text-neutral-300 hover:text-accent text-sm transition-colors duration-200 hover:underline underline-offset-4"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Column 3: Contact Info */}
          <motion.div custom={2} variants={columnVariants}>
            <h3 className="text-white font-display font-semibold text-sm uppercase tracking-wider mb-4">
              {t('footer.contact')}
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5">
                <MapPin className="h-4 w-4 text-neutral-400 mt-0.5 shrink-0" />
                <span className="text-neutral-300 text-sm leading-relaxed">
                  {contactInfo.address[language]}
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 text-neutral-400 shrink-0" />
                <a
                  href={`tel:${contactInfo.phone}`}
                  className="text-neutral-300 hover:text-accent text-sm transition-colors duration-200"
                  dir="ltr"
                >
                  {contactInfo.phone}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 text-neutral-400 shrink-0" />
                <a
                  href={`mailto:${contactInfo.email}`}
                  className="text-neutral-300 hover:text-accent text-sm transition-colors duration-200"
                >
                  {contactInfo.email}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="h-4 w-4 text-neutral-400 mt-0.5 shrink-0" />
                <span className="text-neutral-300 text-sm leading-relaxed">
                  {contactInfo.hours[language]}
                </span>
              </li>
            </ul>
          </motion.div>

          {/* Column 4: Legal */}
          <motion.div custom={3} variants={columnVariants}>
            <h3 className="text-white font-display font-semibold text-sm uppercase tracking-wider mb-4">
              {t('footer.legal')}
            </h3>
            <ul className="space-y-2.5">
              {legalLinks.map((link, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => navigate(link.route)}
                    className="text-neutral-300 hover:text-accent text-sm transition-colors duration-200 hover:underline underline-offset-4"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div
        className="border-t"
        style={{ borderColor: 'rgba(255,255,255,0.1)' }}
      >
        <div className="mx-auto max-w-7xl px-4 md:px-6 py-4 md:py-5">
          <div
            className={`flex flex-col sm:flex-row items-center justify-between gap-2 text-sm text-neutral-400 ${
              isRTL ? 'sm:flex-row-reverse' : ''
            }`}
          >
            <p>
              &copy; {new Date().getFullYear()} {brandText} {t('footer.algeria')}. {t('footer.rights')}
            </p>
            <p className="flex items-center gap-1.5">
              {t('footer.madeWith')}{' '}
              <span className="text-red-400" aria-hidden="true">
                &#10084;
              </span>{' '}
              {t('footer.in')} {t('footer.algeria')}
            </p>
          </div>
        </div>
      </div>
    </motion.footer>
  );
}
