import { NextRequest, NextResponse } from 'next/server';

// ─── System prompt for dental equipment assistant ─────────────
function getSystemPrompt(language: string): string {
  if (language === 'ar') {
    return `أنت المساعد الافتراضي لشركة ODG (مجموعة وقاح لطب الأسنان)، المورد الرائد لمعدات طب الأسنان في الجزائر منذ 2009.

معلومات الشركة:
- الهاتف: 0771 88 89 48
- البريد الإلكتروني: groupedentalimport@gmail.com
- الفاكس: 041 28 28 55
- العنوان: تعاونية عزوز عبد القادر، رقم 45، بلدية السانية، وهران، الجزائر
- ساعات العمل: الأحد - الخميس: 8:00 - 17:00

المنتجات:
- كراسي أسنان (Fauteuils Dentaires)
- وحدات أسنان (Unités Dentaires)
- معدات أشعة (Radiologie)
- معدات تعقيم (Stérilisation)

الخدمات:
- ضمان 2-5 سنوات حسب المنتج
- تركيب وتدريب مجانيان
- خدمة ما بعد البيع في 48 ولاية
- توصيل لجميع الـ 58 ولاية
- طلب عرض سعر مجاني

أجب بإيجاز ومهنية. إذا لم تكن متأكداً، وجه العميل للاتصال بالشركة.`;
  }

  return `Vous êtes l'assistant virtuel d'ODG (OUADAH DENTAL GROUPE), fournisseur leader d'équipements dentaires en Algérie depuis 2009.

Informations société :
- Téléphone : 0771 88 89 48
- Email : groupedentalimport@gmail.com
- Fax : 041 28 28 55
- Adresse : Coopérative Azzouz Abdelkader, N°45, Commune d'Es-Senia, Oran, Algérie
- Horaires : Dimanche - Jeudi : 8h00 - 17h00

Produits :
- Fauteuils Dentaires
- Unités Dentaires
- Radiologie
- Stérilisation

Services :
- Garantie 2 à 5 ans selon le produit
- Installation et formation incluses
- SAV réactif couvrant 48 wilayas
- Livraison dans les 58 wilayas
- Devis gratuit sous 24h

Répondez de manière concise et professionnelle. Si vous n'êtes pas sûr, orientez le client vers le contact de l'entreprise.`;
}

export async function POST(request: NextRequest) {
  try {
    const { messages, language } = await request.json();

    // Try to use z-ai-web-dev-sdk if available
    let aiContent: string | null = null;

    try {
      const ZAI = (await import('z-ai-web-dev-sdk')).default;
      const zai = await ZAI.create();

      const completion = await zai.chat.completions.create({
        messages: [
          { role: 'system', content: getSystemPrompt(language || 'fr') },
          ...messages.slice(-10), // Keep last 10 messages for context
        ],
        temperature: 0.7,
        max_tokens: 500,
      });

      aiContent = completion.choices?.[0]?.message?.content || null;
    } catch {
      // AI SDK not available, use fallback
    }

    if (aiContent) {
      return NextResponse.json({ content: aiContent });
    }

    // Fallback response
    const lastMessage = messages[messages.length - 1]?.content?.toLowerCase() || '';
    const lang = language === 'ar' ? 'ar' : 'fr';

    if (lang === 'ar') {
      if (lastMessage.includes('ساعة') || lastMessage.includes('وقت')) {
        return NextResponse.json({ content: 'ساعات العمل: الأحد - الخميس من 8:00 إلى 17:00.' });
      }
      if (lastMessage.includes('هاتف') || lastMessage.includes('اتصل')) {
        return NextResponse.json({ content: 'رقم الهاتف: 0771 88 89 48 | البريد: groupedentalimport@gmail.com' });
      }
      return NextResponse.json({
        content: 'شكراً لتواصلكم معنا! للحصول على معلومات مفصلة، يمكنكم الاتصال بنا على 0771 88 89 48 أو إرسال بريد إلكتروني إلى groupedentalimport@gmail.com. فريقنا في خدمتكم!',
      });
    }

    if (lastMessage.includes('heure') || lastMessage.includes('horaire')) {
      return NextResponse.json({ content: 'Nos horaires : Dimanche - Jeudi de 8h00 à 17h00.' });
    }
    if (lastMessage.includes('téléphone') || lastMessage.includes('contacter')) {
      return NextResponse.json({ content: 'Téléphone : 0771 88 89 48 | Email : groupedentalimport@gmail.com' });
    }
    return NextResponse.json({
      content: 'Merci de nous contacter ! Pour des informations détaillées, appelez-nous au 0771 88 89 48 ou envoyez un email à groupedentalimport@gmail.com. Notre équipe est à votre disposition !',
    });
  } catch {
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 },
    );
  }
}

export async function GET() {
  return NextResponse.json({ status: 'ok', service: 'ODG Chat API' });
}
