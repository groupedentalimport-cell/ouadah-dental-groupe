'use client';

import { useState, useEffect } from 'react';
import { Download, Eye, Loader2 } from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';

interface QuoteRow {
  id: string;
  nom: string;
  email: string;
  telephone: string;
  wilaya: string;
  type_client: string;
  produits_selectionnes: { id: string; slug: string; name: string | { fr: string; ar: string }; quantity: number }[] | string[];
  message: string;
  statut: 'nouveau' | 'en_cours' | 'traite' | 'archive';
  created_at: string;
}

const statusColors: Record<string, string> = {
  nouveau: 'bg-blue-100 text-blue-700',
  en_cours: 'bg-amber-100 text-amber-700',
  traite: 'bg-green-100 text-green-700',
  archive: 'bg-neutral-100 text-neutral-500',
};

const statusLabels: Record<string, string> = {
  nouveau: 'Nouveau',
  en_cours: 'En cours',
  traite: 'Traité',
  archive: 'Archivé',
};

const allStatuses = ['nouveau', 'en_cours', 'traite', 'archive'];

// Fallback mock data
const mockQuotes: QuoteRow[] = [
  {
    id: '1',
    nom: 'Dr. Benali Karim',
    email: 'benali@email.com',
    telephone: '+213 555 123 456',
    wilaya: 'Alger',
    type_client: 'dentiste',
    produits_selectionnes: [
      { id: '1', slug: 'fauteuil-prestige-x500', name: { fr: 'Fauteuil Prestige X500', ar: 'كرسي بريستيج X500' }, quantity: 1 },
      { id: '3', slug: 'unit-smile-800', name: { fr: 'Unit Smile 800', ar: 'وحدة سمايل 800' }, quantity: 1 },
    ],
    message: 'Je souhaite un devis pour deux fauteuils avec installation.',
    statut: 'nouveau',
    created_at: '2024-03-15T10:00:00Z',
  },
  {
    id: '2',
    nom: 'Dr. Hadj Samira',
    email: 'hadj@email.com',
    telephone: '+213 555 789 012',
    wilaya: 'Oran',
    type_client: 'clinique',
    produits_selectionnes: [
      { id: '5', slug: 'autoclave-steril-pro-23l', name: { fr: 'Autoclave Stéril Pro 23L', ar: 'أوتوكلاف ستريل برو 23 لتر' }, quantity: 1 },
    ],
    message: 'Besoin urgent, cabinet en cours de certification.',
    statut: 'en_cours',
    created_at: '2024-03-14T14:30:00Z',
  },
  {
    id: '3',
    nom: 'Clinique El Amel',
    email: 'elamel@clinic.dz',
    telephone: '+213 555 345 678',
    wilaya: 'Constantine',
    type_client: 'clinique',
    produits_selectionnes: [
      { id: '3', slug: 'unit-smile-800', name: { fr: 'Unit Smile 800', ar: 'وحدة سمايل 800' }, quantity: 2 },
      { id: '4', slug: 'radio-xr200', name: { fr: 'Radio XR200', ar: 'أشعة XR200' }, quantity: 1 },
    ],
    message: 'Équipement complet pour nouveau cabinet.',
    statut: 'traite',
    created_at: '2024-03-13T09:15:00Z',
  },
];

const typeClientLabels: Record<string, string> = {
  dentiste: 'Dentiste',
  clinique: 'Clinique',
  revendeur: 'Revendeur',
  comptoir: 'Comptoir',
};

export default function AdminQuotes() {
  const { t, isRTL } = useTranslation();
  const [filter, setFilter] = useState('all');
  const [quotes, setQuotes] = useState<QuoteRow[]>(mockQuotes);
  const [selectedQuote, setSelectedQuote] = useState<QuoteRow | null>(null);
  const [loading, setLoading] = useState(true);

  // Fetch quotes from Supabase
  const fetchQuotes = async () => {
    if (!isSupabaseConfigured()) {
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('quotes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      if (data && data.length > 0) {
        setQuotes(data as QuoteRow[]);
      }
    } catch (err) {
      console.error('Error fetching quotes:', err);
      // Keep mock data as fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQuotes();
  }, []);

  const filtered =
    filter === 'all'
      ? quotes
      : quotes.filter((q) => q.statut === filter);

  // Update quote status in Supabase
  const updateStatus = async (id: string, newStatus: string) => {
    // Optimistic update
    setQuotes((prev) =>
      prev.map((q) =>
        q.id === id ? { ...q, statut: newStatus as QuoteRow['statut'] } : q
      )
    );

    if (isSupabaseConfigured()) {
      try {
        const { error } = await supabase
          .from('quotes')
          .update({ statut: newStatus })
          .eq('id', id);

        if (error) throw error;
        toast.success(t('common.success'));
      } catch (err) {
        console.error('Error updating quote status:', err);
        toast.error('Erreur lors de la mise à jour');
        // Revert optimistic update
        fetchQuotes();
      }
    } else {
      toast.success(t('common.success'));
    }
  };

  const exportCSV = () => {
    const header = 'Date,Client,Email,Téléphone,Wilaya,Type,Statut\n';
    const rows = quotes
      .map(
        (q) =>
          `"${new Date(q.created_at).toLocaleDateString('fr-FR')}","${q.nom}","${q.email}","${q.telephone}","${q.wilaya}","${typeClientLabels[q.type_client] || q.type_client}","${statusLabels[q.statut]}"`
      )
      .join('\n');
    const blob = new Blob(['\uFEFF' + header + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `devis-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('CSV exporté !');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20" dir={isRTL ? 'rtl' : 'ltr'}>
        <Loader2 className="h-8 w-8 animate-spin text-neutral-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h2 className="text-xl font-bold text-foreground">
          {t('admin.quotes.title')}
        </h2>
        <Button variant="outline" onClick={exportCSV} className="gap-2">
          <Download className="h-4 w-4" />
          Export CSV
        </Button>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-3">
        <span className="text-sm font-medium text-neutral-600">
          {t('common.filter')}:
        </span>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
          >
            {t('common.all')}
          </Button>
          {allStatuses.map((s) => (
            <Button
              key={s}
              variant={filter === s ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(s)}
            >
              {statusLabels[s]}
            </Button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl border border-neutral-200 bg-white overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-200 bg-neutral-50">
                <th className="text-start py-3 px-4 font-medium text-neutral-500">
                  {t('admin.quotes.date')}
                </th>
                <th className="text-start py-3 px-4 font-medium text-neutral-500">
                  {t('admin.quotes.client')}
                </th>
                <th className="text-start py-3 px-4 font-medium text-neutral-500 hidden sm:table-cell">
                  Téléphone
                </th>
                <th className="text-start py-3 px-4 font-medium text-neutral-500 hidden md:table-cell">
                  Wilaya
                </th>
                <th className="text-start py-3 px-4 font-medium text-neutral-500 hidden lg:table-cell">
                  Type
                </th>
                <th className="text-start py-3 px-4 font-medium text-neutral-500">
                  {t('admin.quotes.status')}
                </th>
                <th className="text-start py-3 px-4 font-medium text-neutral-500">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((q) => (
                <tr
                  key={q.id}
                  className="border-b border-neutral-100 hover:bg-neutral-50 transition-colors"
                >
                  <td className="py-3 px-4 text-neutral-700">
                    {new Date(q.created_at).toLocaleDateString('fr-FR')}
                  </td>
                  <td className="py-3 px-4 font-medium text-foreground">
                    {q.nom}
                  </td>
                  <td className="py-3 px-4 text-neutral-600 hidden sm:table-cell">
                    {q.telephone}
                  </td>
                  <td className="py-3 px-4 text-neutral-600 hidden md:table-cell">
                    {q.wilaya}
                  </td>
                  <td className="py-3 px-4 text-neutral-600 hidden lg:table-cell">
                    {typeClientLabels[q.type_client] || q.type_client}
                  </td>
                  <td className="py-3 px-4">
                    <Select
                      value={q.statut}
                      onValueChange={(v) => updateStatus(q.id, v)}
                    >
                      <SelectTrigger className="w-[130px] h-8">
                        <SelectValue>
                          <Badge
                            variant="secondary"
                            className={`${statusColors[q.statut]} cursor-pointer`}
                          >
                            {statusLabels[q.statut]}
                          </Badge>
                        </SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        {allStatuses.map((s) => (
                          <SelectItem key={s} value={s}>
                            {statusLabels[s]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="py-3 px-4">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setSelectedQuote(q)}
                    >
                      <Eye className="h-4 w-4 text-neutral-500" />
                    </Button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td
                    colSpan={7}
                    className="py-12 text-center text-neutral-400"
                  >
                    Aucun devis trouvé
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quote Detail Dialog */}
      <Dialog
        open={!!selectedQuote}
        onOpenChange={() => setSelectedQuote(null)}
      >
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              Devis - {selectedQuote?.nom}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Détails du devis client
            </DialogDescription>
          </DialogHeader>
          {selectedQuote && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-neutral-500">{t('admin.quotes.date')}:</span>
                  <p className="font-medium">{new Date(selectedQuote.created_at).toLocaleDateString('fr-FR')}</p>
                </div>
                <div>
                  <span className="text-neutral-500">{t('admin.quotes.client')}:</span>
                  <p className="font-medium">{selectedQuote.nom}</p>
                </div>
                <div>
                  <span className="text-neutral-500">Téléphone:</span>
                  <p className="font-medium">{selectedQuote.telephone}</p>
                </div>
                <div>
                  <span className="text-neutral-500">Email:</span>
                  <p className="font-medium">{selectedQuote.email}</p>
                </div>
                <div>
                  <span className="text-neutral-500">Wilaya:</span>
                  <p className="font-medium">{selectedQuote.wilaya}</p>
                </div>
                <div>
                  <span className="text-neutral-500">Type:</span>
                  <p className="font-medium">{typeClientLabels[selectedQuote.type_client] || selectedQuote.type_client}</p>
                </div>
                <div className="col-span-2">
                  <span className="text-neutral-500">{t('admin.quotes.status')}:</span>
                  <Badge
                    variant="secondary"
                    className={`ml-2 ${statusColors[selectedQuote.statut]}`}
                  >
                    {statusLabels[selectedQuote.statut]}
                  </Badge>
                </div>
              </div>

              <Separator />

              <div>
                <span className="text-sm text-neutral-500">
                  {t('quote.products')}:
                </span>
                <ul className="mt-1 space-y-1">
                  {(selectedQuote.produits_selectionnes && selectedQuote.produits_selectionnes.length > 0)
                    ? selectedQuote.produits_selectionnes.map((p, i) => {
                        // Handle both formats: string (UUID only) and object (full product info)
                        if (typeof p === 'string') {
                          return (
                            <li key={i} className="text-sm font-medium text-foreground flex items-center gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                              Produit ID: {p}
                            </li>
                          );
                        }
                        const productObj = p as { id: string; slug: string; name: string | { fr: string; ar: string }; quantity: number };
                        const productName = typeof productObj.name === 'object'
                          ? (productObj.name?.fr || productObj.name?.ar || productObj.slug || `Produit ${i + 1}`)
                          : (productObj.name || productObj.slug || `Produit ${i + 1}`);
                        return (
                          <li key={i} className="text-sm font-medium text-foreground flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                            {productName} {productObj.quantity > 1 ? `(x${productObj.quantity})` : ''}
                          </li>
                        );
                      })
                    : <li className="text-sm text-neutral-400">Aucun produit sélectionné</li>
                  }
                </ul>
              </div>

              {selectedQuote.message && (
                <div>
                  <span className="text-sm text-neutral-500">Message:</span>
                  <p className="mt-1 text-sm text-neutral-700 bg-neutral-50 p-3 rounded-lg">
                    {selectedQuote.message}
                  </p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
