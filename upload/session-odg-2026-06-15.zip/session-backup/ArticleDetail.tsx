'use client';

import { useMemo, useState, useEffect, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  ArrowLeft,
  Clock,
  User,
  Copy,
  Share2,
  MessageCircle,
  Expand,
} from 'lucide-react';
import { useTranslation } from '@/lib/i18n';
import { useRouter } from '@/lib/router';
import { useData } from '@/lib/data-service';
import { formatDate } from '@/lib/utils';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import ImageLightbox from './ImageLightbox';

/**
 * Sanitize blog HTML content to prevent raw HTML tags from appearing as text.
 * Handles:
 * - Double-encoded HTML entities
 * - Stray closing tags without matching opening tags (e.g., </p></li></ul><h3>)
 * - Plain text wrapping
 * - Malformed HTML from rich text editors
 */
function sanitizeBlogHtml(html: string): string {
  if (!html) return '';

  let sanitized = html.trim();
  if (!sanitized) return '';

  // Step 1: Decode double-encoded HTML entities
  sanitized = sanitized
    .replace(/&amp;lt;/g, '<')
    .replace(/&amp;gt;/g, '>')
    .replace(/&amp;quot;/g, '"')
    .replace(/&amp;#39;/g, "'")
    .replace(/&amp;amp;/g, '&');

  // Step 2: Remove stray closing tags without matching opening tags
  const openingTags = sanitized.match(/<(p|li|ul|ol|h[1-6]|div|span|strong|em|blockquote|table|tr|td|th|thead|tbody|br)[^>]*>/gi) || [];
  const openingTagNames = openingTags.map(t => {
    const match = t.match(/<\w+/);
    return match ? match[0].toLowerCase().replace('<', '') : '';
  });

  const closingTagPattern = /<\/(p|li|ul|ol|h[1-6]|div|span|strong|em|blockquote|table|tr|td|th|thead|tbody)>/gi;
  const closingTags = sanitized.match(closingTagPattern) || [];
  const closingTagNames = closingTags.map(t => {
    const match = t.match(/<\/\w+/);
    return match ? match[0].toLowerCase().replace('</', '') : '';
  });

  const openCounts: Record<string, number> = {};
  const closeCounts: Record<string, number> = {};
  openingTagNames.forEach(name => { openCounts[name] = (openCounts[name] || 0) + 1; });
  closingTagNames.forEach(name => { closeCounts[name] = (closeCounts[name] || 0) + 1; });

  for (const tagName of Object.keys(closeCounts)) {
    const excess = (closeCounts[tagName] || 0) - (openCounts[tagName] || 0);
    if (excess > 0) {
      let removed = 0;
      sanitized = sanitized.replace(new RegExp(`<\/${tagName}>`, 'gi'), (match) => {
        if (removed < excess) {
          removed++;
          return '';
        }
        return match;
      });
    }
  }

  // Step 3: Clean up whitespace between tags
  sanitized = sanitized.replace(/>\s+</g, '><');

  // Step 4: Wrap plain text in <p>
  if (!sanitized.includes('<')) {
    return `<p>${sanitized}</p>`;
  }

  // Step 5: Wrap content starting with plain text
  if (sanitized.length > 0 && !sanitized.startsWith('<')) {
    sanitized = `<p>${sanitized}</p>`;
  }

  // Step 6: Handle stray text after last closing tag
  const lastClosingTag = sanitized.lastIndexOf('</');
  if (lastClosingTag >= 0 && lastClosingTag < sanitized.length - 1) {
    const afterLastTag = sanitized.substring(lastClosingTag);
    const closeTagEnd = afterLastTag.indexOf('>');
    if (closeTagEnd >= 0 && closeTagEnd < afterLastTag.length - 1) {
      const textAfter = afterLastTag.substring(closeTagEnd + 1).trim();
      if (textAfter) {
        sanitized = sanitized.substring(0, lastClosingTag + closeTagEnd + 1) + `<p>${textAfter}</p>`;
      }
    }
  }

  return sanitized;
}

export default function ArticleDetail() {
  const { language, t, isRTL } = useTranslation();
  const { params, navigate } = useRouter();
  const { blogPosts } = useData();
  const slug = params?.slug || '';
  const contentRef = useRef<HTMLDivElement>(null);

  // Lightbox state
  const [lightbox, setLightbox] = useState<{
    isOpen: boolean;
    src: string;
    alt: string;
  }>({
    isOpen: false,
    src: '',
    alt: '',
  });

  const openLightbox = useCallback((src: string, alt: string = '') => {
    setLightbox({ isOpen: true, src, alt });
  }, []);

  const closeLightbox = useCallback(() => {
    setLightbox((prev) => ({ ...prev, isOpen: false }));
  }, []);

  const post = useMemo(
    () => blogPosts.find((p) => p.slug === slug),
    [slug]
  );

  const relatedPosts = useMemo(
    () =>
      post
        ? blogPosts.filter((p) => p.id !== post.id).slice(0, 2)
        : [],
    [post]
  );

  // Make images inside article content clickable
  useEffect(() => {
    const container = contentRef.current;
    if (!container) return;

    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'IMG') {
        e.preventDefault();
        e.stopPropagation();
        const img = target as HTMLImageElement;
        openLightbox(img.src, img.alt || '');
      }
    };

    container.addEventListener('click', handleClick);
    return () => container.removeEventListener('click', handleClick);
  }, [openLightbox, post]);

  if (!post) {
    return (
      <div
        className="flex flex-col items-center justify-center py-24 gap-4"
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <p className="text-neutral-500 text-lg">{t('blog.noPosts')}</p>
        <Button variant="outline" onClick={() => navigate('/blog')}>
          <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''} me-2`} />
          {t('blog.backToBlog')}
        </Button>
      </div>
    );
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success(t('common.copied'));
  };

  const handleWhatsApp = () => {
    const url = encodeURIComponent(window.location.href);
    const text = encodeURIComponent(post.title[language]);
    window.open(`https://wa.me/?text=${text}%20${url}`, '_blank');
  };

  return (
    <div className="w-full" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Cover Image - Full Width, Clickable */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="relative w-full overflow-hidden cursor-pointer group"
        onClick={() => openLightbox(post.image, post.title[language])}
      >
        {/* Image shown at full width with proper aspect ratio */}
        <img
          src={post.image}
          alt={post.title[language]}
          className="w-full h-auto max-h-[70vh] object-contain bg-neutral-100 transition-transform duration-500 group-hover:scale-[1.02]"
        />
        {/* Expand icon overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/0 group-hover:bg-black/20 transition-colors duration-300">
          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-white/90 rounded-full p-3 shadow-lg">
            <Expand className="h-6 w-6 text-neutral-800" />
          </div>
        </div>
        {/* Gradient + Title overlay at bottom */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent">
          <div className="mx-auto max-w-4xl p-6 md:p-10">
            <h1 className="text-2xl md:text-4xl font-bold text-white leading-tight drop-shadow-lg">
              {post.title[language]}
            </h1>
          </div>
        </div>
      </motion.div>

      {/* Article Body */}
      <article className="mx-auto max-w-4xl px-4 md:px-6 py-8 md:py-12">
        {/* Meta */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className={`flex flex-wrap items-center gap-4 text-sm text-neutral-500 mb-6 pb-6 border-b border-neutral-200 ${
            isRTL ? 'flex-row-reverse' : ''
          }`}
        >
          <span className="flex items-center gap-1.5">
            <User className="h-4 w-4" />
            {post.author}
          </span>
          <span>{formatDate(post.date, language)}</span>
          <span className="flex items-center gap-1.5">
            <Clock className="h-4 w-4" />
            {post.readTime} {t('blog.readTime')}
          </span>
        </motion.div>

        {/* Content with clickable images */}
        <motion.div
          ref={contentRef}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="prose prose-neutral max-w-none mb-10
            [&_h2]:text-xl [&_h2]:md:text-2xl [&_h2]:font-bold [&_h2]:mt-8 [&_h2]:mb-4 [&_h2]:text-foreground
            [&_h3]:text-lg [&_h3]:md:text-xl [&_h3]:font-semibold [&_h3]:mt-6 [&_h3]:mb-3 [&_h3]:text-foreground
            [&_p]:text-neutral-700 [&_p]:leading-relaxed [&_p]:mb-4
            [&_ul]:list-disc [&_ul]:pl-6 [&_ul]:mb-4 [&_ul]:space-y-1
            [&_li]:text-neutral-700 [&_li]:leading-relaxed
            [&_img]:rounded-xl [&_img]:cursor-pointer [&_img]:hover:shadow-lg [&_img]:hover:opacity-90 [&_img]:transition-all [&_img]:duration-300 [&_img]:my-6 [&_img]:mx-auto [&_img]:max-w-full
          "
          dangerouslySetInnerHTML={{ __html: sanitizeBlogHtml(post.content[language]) }}
        />

        {/* Share Buttons */}
        <div
          className={`flex items-center gap-3 py-6 border-t border-b border-neutral-200 mb-10 ${
            isRTL ? 'flex-row-reverse' : ''
          }`}
        >
          <span className="text-sm font-medium text-neutral-700">
            {t('blog.share')} :
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={handleCopyLink}
            className="gap-1.5"
          >
            <Copy className="h-4 w-4" />
            {t('common.share')}
          </Button>
          <Button
            size="sm"
            onClick={handleWhatsApp}
            className="gap-1.5 bg-green-600 hover:bg-green-700 text-white"
          >
            <MessageCircle className="h-4 w-4" />
            WhatsApp
          </Button>
        </div>

        {/* Back to Blog */}
        <div className="mb-10">
          <Button
            variant="ghost"
            onClick={() => navigate('/blog')}
            className={`gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <ArrowLeft className={`h-4 w-4 ${isRTL ? 'rotate-180' : ''}`} />
            {t('blog.backToBlog')}
          </Button>
        </div>

        {/* Related Articles */}
        {relatedPosts.length > 0 && (
          <div>
            <h3 className="text-xl font-bold text-foreground mb-4">
              {t('blog.relatedPosts')}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {relatedPosts.map((rp) => (
                <Card
                  key={rp.id}
                  onClick={() => navigate(`/article/${rp.slug}`)}
                  className="group cursor-pointer overflow-hidden transition-all hover:-translate-y-1 hover:shadow-lg"
                >
                  <div
                    className="relative overflow-hidden cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      openLightbox(rp.image, rp.title[language]);
                    }}
                  >
                    <img
                      src={rp.image}
                      alt={rp.title[language]}
                      className="w-full h-auto object-contain bg-neutral-50 max-h-48 transition-transform duration-500 group-hover:scale-105"
                    />
                    {/* Small expand icon */}
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 rounded-full p-1.5 shadow">
                      <Expand className="h-3.5 w-3.5 text-neutral-700" />
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 text-xs text-neutral-500 mb-2">
                      <time>{formatDate(rp.date, language)}</time>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {rp.readTime} {t('blog.readTime')}
                      </span>
                    </div>
                    <h4 className="font-semibold text-foreground line-clamp-2">
                      {rp.title[language]}
                    </h4>
                    <p className="text-sm text-neutral-600 line-clamp-2 mt-1">
                      {rp.excerpt[language]}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </article>

      {/* Lightbox Modal */}
      <ImageLightbox
        src={lightbox.src}
        alt={lightbox.alt}
        isOpen={lightbox.isOpen}
        onClose={closeLightbox}
      />
    </div>
  );
}
